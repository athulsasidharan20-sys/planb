import {
  boolean,
  doublePrecision,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

export const locations = pgTable("locations", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  area: text("area").notNull(),
  x: doublePrecision("x").notNull(),
  y: doublePrecision("y").notNull(),
  kind: text("kind").notNull().default("junction"),
});

export const roads = pgTable("roads", {
  id: text("id").primaryKey(),
  fromId: text("from_id").notNull(),
  toId: text("to_id").notNull(),
  name: text("name").notNull(),
  distanceKm: doublePrecision("distance_km").notNull(),
  blocked: boolean("blocked").notNull().default(false),
});

export const facilities = pgTable("facilities", {
  id: text("id").primaryKey(),
  locationId: text("location_id").notNull(),
  name: text("name").notNull(),
  category: text("category").notNull(),
  services: text("services").array().notNull(),
  status: text("status").notNull().default("available"),
  statusNote: text("status_note").notNull().default(""),
  hours: text("hours").notNull().default(""),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const searches = pgTable("searches", {
  id: serial("id").primaryKey(),
  originId: text("origin_id").notNull(),
  originName: text("origin_name").notNull(),
  need: text("need").notNull(),
  category: text("category").notNull(),
  preferredFacilityId: text("preferred_facility_id"),
  preferredFacilityName: text("preferred_facility_name"),
  preferredStatus: text("preferred_status"),
  recommendedFacilityId: text("recommended_facility_id"),
  recommendedFacilityName: text("recommended_facility_name"),
  recommendedDistanceKm: doublePrecision("recommended_distance_km"),
  alternativesCount: integer("alternatives_count").notNull().default(0),
  blockedRoads: integer("blocked_roads").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
