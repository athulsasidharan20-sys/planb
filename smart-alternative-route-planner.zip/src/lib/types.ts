export type FacilityStatus = "available" | "busy" | "closed" | "unavailable";
export type LocationKind = "junction" | "facility";

export type NetworkLocation = {
  id: string;
  name: string;
  area: string;
  x: number;
  y: number;
  kind: LocationKind;
};

export type NetworkRoad = {
  id: string;
  fromId: string;
  toId: string;
  name: string;
  distanceKm: number;
  blocked: boolean;
};

export type NetworkFacility = {
  id: string;
  locationId: string;
  name: string;
  category: string;
  services: string[];
  status: FacilityStatus;
  statusNote: string;
  hours: string;
  locationName: string;
  area: string;
  x: number;
  y: number;
};

export type Network = {
  locations: NetworkLocation[];
  roads: NetworkRoad[];
  facilities: NetworkFacility[];
};

export type CategoryDef = {
  id: string;
  label: string;
  noun: string;
  icon: string;
  color: string;
  services: string[];
};

export type LocationSeed = NetworkLocation;
export type RoadSeed = {
  id: string;
  fromId: string;
  toId: string;
  name: string;
  distanceKm: number;
};
export type FacilitySeed = {
  id: string;
  locationId: string;
  name: string;
  category: string;
  services: string[];
  status: FacilityStatus;
  statusNote: string;
  hours: string;
};
export type Scenario = {
  id: string;
  label: string;
  blurb: string;
  originId: string;
  need: string;
  preferredFacilityId: string;
};

export type PlanInput = {
  originId: string;
  need: string;
  preferredFacilityId: string | null;
};

export type PlanPathStep = {
  nodeId: string;
  name: string;
  area: string;
  x: number;
  y: number;
  distanceFromOriginKm: number;
};

export type PlanCandidate = {
  facilityId: string;
  facilityName: string;
  category: string;
  locationId: string;
  locationName: string;
  area: string;
  x: number;
  y: number;
  services: string[];
  status: FacilityStatus;
  statusNote: string;
  hours: string;
  distanceKm: number | null;
  nodeIds: string[];
  roadIds: string[];
  roadNames: string[];
  path: PlanPathStep[];
  eligible: boolean;
  ineligibleReason: string | null;
  deltaVsPreferredKm: number | null;
  rank: number | null;
  isPreferred: boolean;
  isRecommended: boolean;
  reasonTags: string[];
};

export type PlanTraceRow = {
  step: number;
  nodeId: string;
  nodeName: string;
  distanceKm: number;
  viaNodeName: string | null;
  roadName: string | null;
};

export type PlanResult = {
  origin: { id: string; name: string; area: string; x: number; y: number };
  need: string;
  category: string;
  categoryLabel: string;
  categoryColor: string;
  preferred: PlanCandidate | null;
  recommended: PlanCandidate | null;
  alternatives: PlanCandidate[];
  ruledOut: PlanCandidate[];
  candidates: PlanCandidate[];
  preferredStillWorks: boolean;
  matchedCount: number;
  eligibleCount: number;
  unreachableCount: number;
  blockedRoadCount: number;
  trace: PlanTraceRow[];
  algorithm: {
    nodesSettled: number;
    edgesRelaxed: number;
    nodesInGraph: number;
    edgesInGraph: number;
    computationMs: number;
    complexity: string;
  };
};
