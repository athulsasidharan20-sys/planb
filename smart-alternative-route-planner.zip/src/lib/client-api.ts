export async function postJson<T>(url: string, body?: unknown): Promise<T> {
  const response = await fetch(url, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body ?? {}),
  });
  const data: unknown = await response.json().catch(() => null);
  if (!response.ok) {
    const message =
      (data as { error?: string } | null)?.error ?? "Request failed. Please try again.";
    throw new Error(message);
  }
  return data as T;
}
