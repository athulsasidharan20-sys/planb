import { buildGraph, dijkstra, reconstructPath } from "./dijkstra";
import { CATEGORIES, categoryForService } from "./city-data";
import type {
  Network,
  NetworkFacility,
  PlanCandidate,
  PlanInput,
  PlanResult,
  PlanTraceRow,
} from "./types";

const round = (value: number) => Math.round(value * 100) / 100;

function ineligibleReason(facility: NetworkFacility): string {
  if (facility.status === "closed") return facility.statusNote || "Closed right now";
  if (facility.status === "busy")
    return facility.statusNote || "At full capacity, cannot take you in";
  if (facility.status === "unavailable")
    return facility.statusNote || "Required service is currently unavailable";
  return facility.statusNote || "Not available";
}

export function computePlan(network: Network, input: PlanInput): PlanResult {
  const startedAt = performance.now();
  const origin = network.locations.find((location) => location.id === input.originId);
  if (!origin) throw new Error(`Unknown origin location: ${input.originId}`);

  const category = categoryForService(input.need) ?? CATEGORIES[0];
  const graph = buildGraph(network);
  const run = dijkstra(graph, origin.id);
  const locationById = new Map(network.locations.map((location) => [location.id, location]));

  const matched = network.facilities
    .filter((facility) => facility.services.includes(input.need))
    .sort((a, b) => a.name.localeCompare(b.name));

  const preferredFacility =
    (input.preferredFacilityId
      ? matched.find((facility) => facility.id === input.preferredFacilityId)
      : undefined) ?? null;

  const buildCandidate = (facility: NetworkFacility): PlanCandidate => {
    const path = reconstructPath(run, origin.id, facility.locationId);
    const distanceKm = path ? round(path.distanceKm) : null;
    const eligible = facility.status === "available" && path !== null;
    const reason = !path
      ? network.roads.some((road) => road.blocked)
        ? "No open route — a closed road cuts every path from your origin"
        : "No route exists from your origin"
      : ineligibleReason(facility);

    return {
      facilityId: facility.id,
      facilityName: facility.name,
      category: facility.category,
      locationId: facility.locationId,
      locationName: facility.locationName,
      area: facility.area,
      x: facility.x,
      y: facility.y,
      services: facility.services,
      status: facility.status,
      statusNote: facility.statusNote,
      hours: facility.hours,
      distanceKm,
      nodeIds: path?.nodeIds ?? [],
      roadIds: path?.roadIds ?? [],
      roadNames: path?.roadNames ?? [],
      path:
        path?.nodeIds.map((nodeId) => {
          const node = locationById.get(nodeId);
          return {
            nodeId,
            name: node?.name ?? nodeId,
            area: node?.area ?? "",
            x: node?.x ?? 0,
            y: node?.y ?? 0,
            distanceFromOriginKm: round(run.distances.get(nodeId) ?? 0),
          };
        }) ?? [],
      eligible,
      ineligibleReason: eligible ? null : reason,
      deltaVsPreferredKm: null,
      rank: null,
      isPreferred: preferredFacility?.id === facility.id,
      isRecommended: false,
      reasonTags: [],
    };
  };

  const candidates = matched.map(buildCandidate);
  const preferred = preferredFacility
    ? candidates.find((candidate) => candidate.facilityId === preferredFacility.id) ?? null
    : null;

  const baseline = preferred?.distanceKm ?? null;
  for (const candidate of candidates) {
    candidate.deltaVsPreferredKm =
      baseline !== null && candidate.distanceKm !== null
        ? round(candidate.distanceKm - baseline)
        : null;
  }

  const eligible = candidates
    .filter((candidate) => candidate.eligible)
    .sort((a, b) => (a.distanceKm ?? 0) - (b.distanceKm ?? 0));

  const ruledOut = candidates
    .filter((candidate) => !candidate.eligible)
    .sort((a, b) => (a.distanceKm ?? Number.MAX_SAFE_INTEGER) - (b.distanceKm ?? Number.MAX_SAFE_INTEGER));

  const preferredStillWorks = Boolean(preferred?.eligible);
  const recommended = preferredStillWorks && preferred ? preferred : eligible[0] ?? null;
  const alternatives = eligible.filter(
    (candidate) => candidate.facilityId !== recommended?.facilityId,
  );

  if (recommended) {
    recommended.rank = 1;
    recommended.isRecommended = true;
    recommended.reasonTags = [
      recommended.isPreferred ? "Original plan holds" : "Nearest open route",
      `Offers ${input.need}`,
      recommended.isPreferred
        ? `${eligible.length} viable option${eligible.length === 1 ? "" : "s"} compared`
        : recommended.deltaVsPreferredKm !== null && recommended.deltaVsPreferredKm < 0
          ? `Saves ${Math.abs(recommended.deltaVsPreferredKm).toFixed(1)} km`
          : recommended.deltaVsPreferredKm !== null && recommended.deltaVsPreferredKm > 0
            ? `${recommended.deltaVsPreferredKm.toFixed(1)} km further`
            : "Shortest finalized distance",
    ];
  }

  alternatives.forEach((candidate, index) => {
    candidate.rank = index + 2;
    const tags = [index === 0 ? "Backup · next nearest" : "Backup option"];
    if (candidate.deltaVsPreferredKm !== null && candidate.deltaVsPreferredKm < 0) {
      tags.push(`${Math.abs(candidate.deltaVsPreferredKm).toFixed(1)} km closer than Plan A`);
    }
    candidate.reasonTags = tags;
  });

  for (const candidate of ruledOut) {
    candidate.reasonTags = [candidate.ineligibleReason ?? "Not eligible"];
  }

  const trace: PlanTraceRow[] = run.settled.map((row, index) => ({
    step: index + 1,
    nodeId: row.nodeId,
    nodeName: locationById.get(row.nodeId)?.name ?? row.nodeId,
    distanceKm: round(row.distanceKm),
    viaNodeName: row.previous ? locationById.get(row.previous.nodeId)?.name ?? row.previous.nodeId : null,
    roadName: row.previous?.roadName ?? null,
  }));

  return {
    origin: { id: origin.id, name: origin.name, area: origin.area, x: origin.x, y: origin.y },
    need: input.need,
    category: category.id,
    categoryLabel: category.label,
    categoryColor: category.color,
    preferred,
    recommended,
    alternatives,
    ruledOut,
    candidates: [
      ...(recommended ? [recommended] : []),
      ...alternatives,
      ...ruledOut.filter((candidate) => candidate.facilityId !== recommended?.facilityId),
    ],
    preferredStillWorks,
    matchedCount: matched.length,
    eligibleCount: eligible.length,
    unreachableCount: candidates.filter((candidate) => candidate.distanceKm === null).length,
    blockedRoadCount: network.roads.filter((road) => road.blocked).length,
    trace,
    algorithm: {
      nodesSettled: run.settled.length,
      edgesRelaxed: run.relaxations,
      nodesInGraph: network.locations.length,
      edgesInGraph: network.roads.filter((road) => !road.blocked).length,
      computationMs: Math.max(1, Math.round((performance.now() - startedAt) * 10) / 10),
      complexity: "O((V + E) log V)",
    },
  };
}
