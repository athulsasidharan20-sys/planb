import { and, desc, eq, isNotNull, sql } from "drizzle-orm";
import { db } from "@/db";
import { facilities, locations, roads, searches } from "@/db/schema";
import { FACILITIES, LOCATIONS, ROADS } from "./city-data";
import type { FacilityStatus, Network, PlanResult } from "./types";

const DDL: string[] = [
  `create table if not exists locations (
    id text primary key,
    name text not null,
    area text not null,
    x double precision not null,
    y double precision not null,
    kind text not null default 'junction'
  )`,
  `create table if not exists roads (
    id text primary key,
    from_id text not null,
    to_id text not null,
    name text not null,
    distance_km double precision not null,
    blocked boolean not null default false
  )`,
  `create table if not exists facilities (
    id text primary key,
    location_id text not null,
    name text not null,
    category text not null,
    services text[] not null default '{}'::text[],
    status text not null default 'available',
    status_note text not null default '',
    hours text not null default '',
    updated_at timestamptz not null default now()
  )`,
  `create table if not exists searches (
    id serial primary key,
    origin_id text not null,
    origin_name text not null,
    need text not null,
    category text not null,
    preferred_facility_id text,
    preferred_facility_name text,
    preferred_status text,
    recommended_facility_id text,
    recommended_facility_name text,
    recommended_distance_km double precision,
    alternatives_count integer not null default 0,
    blocked_roads integer not null default 0,
    created_at timestamptz not null default now()
  )`,
];

const SAMPLE_RUNS = [
  {
    originId: "j-sector17",
    originName: "Sector 17 Plaza",
    need: "Cardiology",
    category: "hospital",
    preferredFacilityId: "f-sunrise-general",
    preferredFacilityName: "Sunrise General Hospital",
    preferredStatus: "unavailable",
    recommendedFacilityId: "f-green-valley",
    recommendedFacilityName: "Green Valley Hospital",
    recommendedDistanceKm: 3.4,
    alternativesCount: 2,
    blockedRoads: 0,
    minutesAgo: 26,
  },
  {
    originId: "j-lakeside",
    originName: "Lakeside",
    need: "Fast Charging (CCS2)",
    category: "ev",
    preferredFacilityId: "f-techpark-charge",
    preferredFacilityName: "TechPark Supercharge",
    preferredStatus: "busy",
    recommendedFacilityId: "f-lakeview-ev",
    recommendedFacilityName: "Lakeview EV Plaza",
    recommendedDistanceKm: 0.6,
    alternativesCount: 2,
    blockedRoads: 1,
    minutesAgo: 84,
  },
  {
    originId: "j-riverside",
    originName: "Riverside",
    need: "Cash Withdrawal",
    category: "atm",
    preferredFacilityId: "f-city-atm-museum",
    preferredFacilityName: "CityBank ATM · Museum Cross",
    preferredStatus: "unavailable",
    recommendedFacilityId: "f-south-atm",
    recommendedFacilityName: "South Market ATM",
    recommendedDistanceKm: 1.7,
    alternativesCount: 2,
    blockedRoads: 0,
    minutesAgo: 190,
  },
  {
    originId: "j-southmarket",
    originName: "South Market",
    need: "Study Desks",
    category: "library",
    preferredFacilityId: "f-oldtown-reading",
    preferredFacilityName: "Old Town Reading Room",
    preferredStatus: "closed",
    recommendedFacilityId: "f-riverside-study",
    recommendedFacilityName: "Riverside Study Rooms",
    recommendedDistanceKm: 1.8,
    alternativesCount: 2,
    blockedRoads: 0,
    minutesAgo: 320,
  },
  {
    originId: "j-northgate",
    originName: "North Gate",
    need: "Passport Renewal",
    category: "service",
    preferredFacilityId: "f-citizen-east",
    preferredFacilityName: "Citizen Service Centre · East",
    preferredStatus: "available",
    recommendedFacilityId: "f-citizen-east",
    recommendedFacilityName: "Citizen Service Centre · East",
    recommendedDistanceKm: 5.75,
    alternativesCount: 1,
    blockedRoads: 2,
    minutesAgo: 640,
  },
];

let bootstrapPromise: Promise<void> | null = null;

async function bootstrap(): Promise<void> {
  for (const statement of DDL) {
    await db.execute(sql.raw(statement));
  }

  await db
    .insert(locations)
    .values(LOCATIONS.map((location) => ({ ...location })))
    .onConflictDoNothing();

  await db
    .insert(roads)
    .values(ROADS.map((road) => ({ ...road, blocked: false })))
    .onConflictDoNothing();

  await db
    .insert(facilities)
    .values(
      FACILITIES.map((facility) => ({
        ...facility,
        statusNote: facility.statusNote,
      })),
    )
    .onConflictDoNothing();

  const [{ count }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(searches);

  if (Number(count) === 0) {
    await db.insert(searches).values(
      SAMPLE_RUNS.map(({ minutesAgo, ...run }) => ({
        ...run,
        createdAt: new Date(Date.now() - minutesAgo * 60_000),
      })),
    );
  }
}

export function ensureDatabase(): Promise<void> {
  if (!bootstrapPromise) {
    bootstrapPromise = bootstrap().catch((error: unknown) => {
      bootstrapPromise = null;
      throw error;
    });
  }
  return bootstrapPromise;
}

function toStatus(value: string): FacilityStatus {
  if (value === "busy" || value === "closed" || value === "unavailable") return value;
  return "available";
}

export async function getNetwork(): Promise<Network> {
  await ensureDatabase();
  const [locationRows, roadRows, facilityRows] = await Promise.all([
    db.select().from(locations),
    db.select().from(roads),
    db.select().from(facilities),
  ]);

  const locationById = new Map(locationRows.map((location) => [location.id, location]));

  return {
    locations: locationRows
      .map((location) => ({
        id: location.id,
        name: location.name,
        area: location.area,
        x: location.x,
        y: location.y,
        kind: location.kind === "facility" ? ("facility" as const) : ("junction" as const),
      }))
      .sort((a, b) => (a.kind === b.kind ? a.name.localeCompare(b.name) : a.kind === "junction" ? -1 : 1)),
    roads: roadRows
      .map((road) => ({
        id: road.id,
        fromId: road.fromId,
        toId: road.toId,
        name: road.name,
        distanceKm: road.distanceKm,
        blocked: road.blocked,
      }))
      .sort((a, b) => a.id.localeCompare(b.id)),
    facilities: facilityRows
      .map((facility) => {
        const location = locationById.get(facility.locationId);
        return {
          id: facility.id,
          locationId: facility.locationId,
          name: facility.name,
          category: facility.category,
          services: facility.services,
          status: toStatus(facility.status),
          statusNote: facility.statusNote,
          hours: facility.hours,
          locationName: location?.name ?? facility.name,
          area: location?.area ?? "",
          x: location?.x ?? 0,
          y: location?.y ?? 0,
        };
      })
      .sort((a, b) => a.name.localeCompare(b.name)),
  };
}

export async function setFacilityStatus(id: string, status: FacilityStatus): Promise<boolean> {
  await ensureDatabase();
  const updated = await db
    .update(facilities)
    .set({ status, updatedAt: new Date() })
    .where(eq(facilities.id, id))
    .returning({ id: facilities.id });
  return updated.length > 0;
}

export async function setRoadBlocked(id: string, blocked: boolean): Promise<boolean> {
  await ensureDatabase();
  const updated = await db
    .update(roads)
    .set({ blocked })
    .where(eq(roads.id, id))
    .returning({ id: roads.id });
  return updated.length > 0;
}

export async function resetDemo(): Promise<void> {
  await ensureDatabase();
  await db.update(roads).set({ blocked: false });
  for (const seed of FACILITIES) {
    await db
      .update(facilities)
      .set({ status: seed.status, statusNote: seed.statusNote, updatedAt: new Date() })
      .where(eq(facilities.id, seed.id));
  }
}

export async function recordSearch(plan: PlanResult): Promise<void> {
  await ensureDatabase();
  await db.insert(searches).values({
    originId: plan.origin.id,
    originName: plan.origin.name,
    need: plan.need,
    category: plan.category,
    preferredFacilityId: plan.preferred?.facilityId ?? null,
    preferredFacilityName: plan.preferred?.facilityName ?? null,
    preferredStatus: plan.preferred?.status ?? null,
    recommendedFacilityId: plan.recommended?.facilityId ?? null,
    recommendedFacilityName: plan.recommended?.facilityName ?? null,
    recommendedDistanceKm: plan.recommended?.distanceKm ?? null,
    alternativesCount: plan.alternatives.length,
    blockedRoads: plan.blockedRoadCount,
  });
}

export type SearchHistoryRow = {
  id: number;
  originName: string;
  need: string;
  category: string;
  preferredFacilityName: string | null;
  preferredStatus: string | null;
  recommendedFacilityName: string | null;
  recommendedDistanceKm: number | null;
  alternativesCount: number;
  blockedRoads: number;
  createdAt: string;
};

export async function getSearchHistory(limit = 24): Promise<SearchHistoryRow[]> {
  await ensureDatabase();
  const rows = await db
    .select()
    .from(searches)
    .orderBy(desc(searches.createdAt), desc(searches.id))
    .limit(limit);

  return rows.map((row) => ({
    id: row.id,
    originName: row.originName,
    need: row.need,
    category: row.category,
    preferredFacilityName: row.preferredFacilityName,
    preferredStatus: row.preferredStatus,
    recommendedFacilityName: row.recommendedFacilityName,
    recommendedDistanceKm: row.recommendedDistanceKm,
    alternativesCount: row.alternativesCount,
    blockedRoads: row.blockedRoads,
    createdAt: row.createdAt.toISOString(),
  }));
}

export type ActivityStats = {
  total: number;
  avgAlternatives: number;
  avgDistance: number;
  recalculated: number;
  topNeeds: { need: string; count: number }[];
  topDestinations: { name: string; count: number }[];
};

export async function getActivityStats(): Promise<ActivityStats> {
  await ensureDatabase();
  const [totals] = await db
    .select({
      total: sql<number>`count(*)::int`,
      avgAlternatives: sql<number>`coalesce(round(avg(${searches.alternativesCount})::numeric, 1), 0)::float`,
      avgDistance: sql<number>`coalesce(round(avg(${searches.recommendedDistanceKm})::numeric, 2), 0)::float`,
      recalculated: sql<number>`coalesce(sum(case when ${searches.blockedRoads} > 0 then 1 else 0 end), 0)::int`,
    })
    .from(searches);

  const topNeeds = await db
    .select({ need: searches.need, count: sql<number>`count(*)::int` })
    .from(searches)
    .groupBy(searches.need)
    .orderBy(desc(sql`count(*)`))
    .limit(4);

  const topDestinations = await db
    .select({
      name: sql<string>`coalesce(${searches.recommendedFacilityName}, 'No match')`,
      count: sql<number>`count(*)::int`,
    })
    .from(searches)
    .where(and(isNotNull(searches.recommendedFacilityId), isNotNull(searches.recommendedFacilityName)))
    .groupBy(searches.recommendedFacilityName)
    .orderBy(desc(sql`count(*)`))
    .limit(4);

  return {
    total: Number(totals?.total ?? 0),
    avgAlternatives: Number(totals?.avgAlternatives ?? 0),
    avgDistance: Number(totals?.avgDistance ?? 0),
    recalculated: Number(totals?.recalculated ?? 0),
    topNeeds: topNeeds.map((row) => ({ need: row.need, count: Number(row.count) })),
    topDestinations: topDestinations.map((row) => ({ name: row.name, count: Number(row.count) })),
  };
}
