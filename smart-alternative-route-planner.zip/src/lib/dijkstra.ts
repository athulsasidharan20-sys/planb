import type { Network } from "./types";

export type GraphEdge = {
  to: string;
  km: number;
  roadId: string;
  roadName: string;
};

export type WeightedGraph = Map<string, GraphEdge[]>;

export type SettledNode = {
  nodeId: string;
  distanceKm: number;
  previous: { nodeId: string; roadId: string; roadName: string } | null;
};

export type DijkstraRun = {
  distances: Map<string, number>;
  previous: Map<string, { nodeId: string; roadId: string; roadName: string } | null>;
  settled: SettledNode[];
  relaxations: number;
};

/** Build an undirected adjacency list from roads, dropping closed roads. */
export function buildGraph(network: Network): WeightedGraph {
  const graph: WeightedGraph = new Map();
  for (const location of network.locations) graph.set(location.id, []);
  for (const road of network.roads) {
    if (road.blocked) continue;
    graph.get(road.fromId)?.push({
      to: road.toId,
      km: road.distanceKm,
      roadId: road.id,
      roadName: road.name,
    });
    graph.get(road.toId)?.push({
      to: road.fromId,
      km: road.distanceKm,
      roadId: road.id,
      roadName: road.name,
    });
  }
  return graph;
}

type HeapItem = { nodeId: string; distanceKm: number };

/** Minimal binary min-heap keyed by tentative distance. */
class MinHeap {
  private items: HeapItem[] = [];

  get size(): number {
    return this.items.length;
  }

  push(item: HeapItem): void {
    this.items.push(item);
    let index = this.items.length - 1;
    while (index > 0) {
      const parent = Math.floor((index - 1) / 2);
      if (this.items[parent].distanceKm <= this.items[index].distanceKm) break;
      [this.items[parent], this.items[index]] = [this.items[index], this.items[parent]];
      index = parent;
    }
  }

  pop(): HeapItem | undefined {
    if (this.items.length === 0) return undefined;
    const top = this.items[0];
    const last = this.items.pop();
    if (this.items.length > 0 && last) {
      this.items[0] = last;
      let index = 0;
      for (;;) {
        const left = index * 2 + 1;
        const right = index * 2 + 2;
        let smallest = index;
        if (
          left < this.items.length &&
          this.items[left].distanceKm < this.items[smallest].distanceKm
        ) {
          smallest = left;
        }
        if (
          right < this.items.length &&
          this.items[right].distanceKm < this.items[smallest].distanceKm
        ) {
          smallest = right;
        }
        if (smallest === index) break;
        [this.items[smallest], this.items[index]] = [this.items[index], this.items[smallest]];
        index = smallest;
      }
    }
    return top;
  }
}

/** Classic Dijkstra single-source shortest paths over a weighted graph. */
export function dijkstra(graph: WeightedGraph, source: string): DijkstraRun {
  const distances = new Map<string, number>();
  const previous = new Map<string, { nodeId: string; roadId: string; roadName: string } | null>();
  const settled: SettledNode[] = [];
  const visited = new Set<string>();
  const heap = new MinHeap();
  let relaxations = 0;

  distances.set(source, 0);
  previous.set(source, null);
  heap.push({ nodeId: source, distanceKm: 0 });

  while (heap.size > 0) {
    const current = heap.pop();
    if (!current) break;
    if (visited.has(current.nodeId)) continue;
    visited.add(current.nodeId);

    const distance = distances.get(current.nodeId) ?? Number.POSITIVE_INFINITY;
    settled.push({
      nodeId: current.nodeId,
      distanceKm: distance,
      previous: previous.get(current.nodeId) ?? null,
    });

    for (const edge of graph.get(current.nodeId) ?? []) {
      if (visited.has(edge.to)) continue;
      const candidate = distance + edge.km;
      const known = distances.get(edge.to) ?? Number.POSITIVE_INFINITY;
      if (candidate < known - 1e-9) {
        distances.set(edge.to, candidate);
        previous.set(edge.to, {
          nodeId: current.nodeId,
          roadId: edge.roadId,
          roadName: edge.roadName,
        });
        heap.push({ nodeId: edge.to, distanceKm: candidate });
        relaxations += 1;
      }
    }
  }

  return { distances, previous, settled, relaxations };
}

export type ShortestPath = {
  nodeIds: string[];
  roadIds: string[];
  roadNames: string[];
  distanceKm: number;
};

/** Walk the predecessor map backwards to rebuild the road-by-road route. */
export function reconstructPath(
  run: DijkstraRun,
  source: string,
  target: string,
): ShortestPath | null {
  if (!run.distances.has(target)) return null;

  const nodeIds: string[] = [];
  const roadIds: string[] = [];
  const roadNames: string[] = [];
  let cursor: string | null = target;

  while (cursor) {
    nodeIds.unshift(cursor);
    const step: { nodeId: string; roadId: string; roadName: string } | null =
      run.previous.get(cursor) ?? null;
    if (!step) break;
    roadIds.unshift(step.roadId);
    roadNames.unshift(step.roadName);
    cursor = step.nodeId;
  }

  if (nodeIds[0] !== source) return null;
  return { nodeIds, roadIds, roadNames, distanceKm: run.distances.get(target) ?? 0 };
}
