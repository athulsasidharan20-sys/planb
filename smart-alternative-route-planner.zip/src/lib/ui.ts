import type { FacilityStatus } from "./types";

export const STATUS_META: Record<
  FacilityStatus,
  { label: string; dot: string; text: string; surface: string; border: string }
> = {
  available: {
    label: "Available",
    dot: "bg-[#7CF2B0]",
    text: "text-[#9DF8C9]",
    surface: "bg-[#7CF2B0]/10",
    border: "border-[#7CF2B0]/30",
  },
  busy: {
    label: "At capacity",
    dot: "bg-[#FFC46B]",
    text: "text-[#FFD79A]",
    surface: "bg-[#FFC46B]/10",
    border: "border-[#FFC46B]/30",
  },
  closed: {
    label: "Closed",
    dot: "bg-[#FF8296]",
    text: "text-[#FFB3C0]",
    surface: "bg-[#FF8296]/10",
    border: "border-[#FF8296]/30",
  },
  unavailable: {
    label: "Service unavailable",
    dot: "bg-[#FF8296]",
    text: "text-[#FFB3C0]",
    surface: "bg-[#FF8296]/10",
    border: "border-[#FF8296]/30",
  },
};

export const STATUS_ORDER: FacilityStatus[] = ["available", "busy", "closed", "unavailable"];

export function formatKm(value: number | null): string {
  if (value === null || Number.isNaN(value)) return "—";
  return value.toFixed(value < 10 ? 1 : 1);
}

export function formatDelta(value: number | null): string | null {
  if (value === null || value === 0) return value === 0 ? "same as Plan A" : null;
  const sign = value > 0 ? "+" : "−";
  return `${sign}${Math.abs(value).toFixed(1)} km vs Plan A`;
}

export function etaMinutes(km: number | null): number | null {
  if (km === null) return null;
  return Math.max(2, Math.round((km / 24) * 60));
}

export function formatDateTime(iso: string): string {
  return new Intl.DateTimeFormat("en-GB", {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
    timeZone: "UTC",
  }).format(new Date(iso));
}
