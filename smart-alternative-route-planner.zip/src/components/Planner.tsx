"use client";

import { useMemo, useState, type FormEvent, type ReactNode } from "react";
import Link from "next/link";
import NetworkMap from "./NetworkMap";
import StatusPill from "./StatusPill";
import { postJson } from "@/lib/client-api";
import { CATEGORIES, SCENARIOS } from "@/lib/city-data";
import type { Network, PlanCandidate, PlanResult } from "@/lib/types";
import { STATUS_META, etaMinutes, formatDelta, formatKm } from "@/lib/ui";

type Props = {
  initialNetwork: Network;
  initialPlan: PlanResult;
};

function Chevron() {
  return (
    <span className="pointer-events-none absolute right-3.5 top-1/2 -translate-y-1/2 text-[10px] text-white/35">
      ▾
    </span>
  );
}

function StepLabel({
  step,
  htmlFor,
  children,
}: {
  step: string;
  htmlFor: string;
  children: ReactNode;
}) {
  return (
    <label
      htmlFor={htmlFor}
      className="flex items-center gap-2 text-[11px] font-medium uppercase tracking-[0.14em] text-white/40"
    >
      <span className="font-mono text-[10px] text-[#7CF2B0]/80">{step}</span>
      {children}
    </label>
  );
}

export default function Planner({ initialNetwork, initialPlan }: Props) {
  const [network, setNetwork] = useState<Network>(initialNetwork);
  const [plan, setPlan] = useState<PlanResult>(initialPlan);
  const [originId, setOriginId] = useState(initialPlan.origin.id);
  const [need, setNeed] = useState(initialPlan.need);
  const [preferredId, setPreferredId] = useState(initialPlan.preferred?.facilityId ?? "");
  const [pending, setPending] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [showAllPins, setShowAllPins] = useState(false);
  const [traceOpen, setTraceOpen] = useState(false);

  const origins = useMemo(
    () => network.locations.filter((location) => location.kind === "junction"),
    [network.locations],
  );
  const preferredOptions = useMemo(
    () =>
      network.facilities
        .filter((facility) => facility.services.includes(need))
        .sort((a, b) => a.name.localeCompare(b.name)),
    [network.facilities, need],
  );
  const preferredFacility = preferredOptions.find((facility) => facility.id === preferredId) ?? null;
  const activeScenarioId =
    SCENARIOS.find(
      (scenario) =>
        scenario.originId === originId &&
        scenario.need === need &&
        scenario.preferredFacilityId === preferredId,
    )?.id ?? null;

  const facilityNamesByNode = useMemo(() => {
    const map = new Map<string, string[]>();
    for (const facility of network.facilities) {
      const list = map.get(facility.locationId) ?? [];
      list.push(facility.name);
      map.set(facility.locationId, list);
    }
    return map;
  }, [network.facilities]);

  async function recalc(
    overrides: Partial<{ originId: string; need: string; preferredFacilityId: string | null }> = {},
  ) {
    const payload = {
      originId: overrides.originId ?? originId,
      need: overrides.need ?? need,
      preferredFacilityId:
        overrides.preferredFacilityId !== undefined
          ? overrides.preferredFacilityId
          : preferredId || null,
    };
    setPending(true);
    setError(null);
    try {
      const data = await postJson<{ plan: PlanResult }>("/api/plan", payload);
      setPlan(data.plan);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "PlanB could not compute a plan.");
    } finally {
      setPending(false);
    }
  }

  function submit(event: FormEvent) {
    event.preventDefault();
    void recalc();
  }

  function applyScenario(scenarioId: string) {
    const scenario = SCENARIOS.find((item) => item.id === scenarioId);
    if (!scenario) return;
    setOriginId(scenario.originId);
    setNeed(scenario.need);
    setPreferredId(scenario.preferredFacilityId);
    setNotice(scenario.blurb);
    void recalc({
      originId: scenario.originId,
      need: scenario.need,
      preferredFacilityId: scenario.preferredFacilityId,
    });
  }

  function changeNeed(nextNeed: string) {
    const matching = network.facilities
      .filter((facility) => facility.services.includes(nextNeed))
      .sort((a, b) => a.name.localeCompare(b.name));
    const keep = matching.find((facility) => facility.id === preferredId);
    const nextPreferred = keep?.id ?? matching[0]?.id ?? "";
    setNeed(nextNeed);
    setPreferredId(nextPreferred);
    void recalc({ need: nextNeed, preferredFacilityId: nextPreferred || null });
  }

  function makePreferred(candidate: PlanCandidate) {
    setPreferredId(candidate.facilityId);
    void recalc({ preferredFacilityId: candidate.facilityId });
  }

  function selectFacility(facilityId: string) {
    const facility = network.facilities.find((item) => item.id === facilityId);
    if (!facility) return;
    const nextNeed = facility.services.includes(need) ? need : facility.services[0];
    setNeed(nextNeed);
    setPreferredId(facility.id);
    void recalc({ need: nextNeed, preferredFacilityId: facility.id });
  }

  async function toggleRoad(roadId: string) {
    if (pending) return;
    const road = network.roads.find((item) => item.id === roadId);
    if (!road) return;
    setPending(true);
    setError(null);
    try {
      const data = await postJson<{ network: Network }>(`/api/roads/${roadId}`, {
        blocked: !road.blocked,
      });
      setNetwork(data.network);
      setNotice(`${road.name} ${road.blocked ? "reopened" : "closed"} — re-running Dijkstra.`);
      await recalc();
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Could not update that road.");
      setPending(false);
    }
  }

  async function resetNetwork() {
    setPending(true);
    setError(null);
    try {
      const data = await postJson<{ network: Network }>("/api/reset");
      setNetwork(data.network);
      setNotice("Demo network restored — all roads open, statuses reset.");
      await recalc();
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Could not reset the network.");
      setPending(false);
    }
  }

  async function copyRoute() {
    if (!plan.recommended) return;
    const base = plan.recommended;
    const lines = base.path.map((step, index) =>
      index === 0
        ? `Start · ${step.name}`
        : `${index}. ${step.name} — via ${base.roadNames[index - 1] ?? "road"}`,
    );
    const text = `PlanB · ${plan.origin.name} → ${base.facilityName} (${formatKm(base.distanceKm)} km)\n${lines.join("\n")}`;
    try {
      await navigator.clipboard.writeText(text);
      setNotice("Route directions copied to clipboard.");
    } catch {
      setError("Clipboard is unavailable in this browser.");
    }
  }

  const recommended = plan.recommended;
  const alternatives = plan.alternatives;
  const compareList = [...plan.candidates].sort(
    (a, b) => (a.distanceKm ?? Number.MAX_SAFE_INTEGER) - (b.distanceKm ?? Number.MAX_SAFE_INTEGER),
  );
  const maxDistance = Math.max(
    0.5,
    ...compareList.map((candidate) => candidate.distanceKm ?? 0),
  );

  return (
    <div className="space-y-6" aria-busy={pending}>
      <div className="flex flex-wrap items-center gap-2">
        <span className="mr-1 text-[11px] uppercase tracking-[0.16em] text-white/35">
          Try a scenario
        </span>
        {SCENARIOS.map((scenario) => {
          const active = activeScenarioId === scenario.id;
          return (
            <button
              key={scenario.id}
              type="button"
              onClick={() => applyScenario(scenario.id)}
              disabled={pending}
              className={`rounded-full border px-3 py-1.5 text-xs font-medium transition disabled:cursor-wait ${
                active
                  ? "border-[#7CF2B0]/50 bg-[#7CF2B0]/15 text-[#C9FFE3]"
                  : "border-white/10 bg-white/[0.03] text-white/60 hover:border-white/20 hover:text-white/90"
              }`}
            >
              {scenario.label}
            </button>
          );
        })}
        <button
          type="button"
          onClick={resetNetwork}
          disabled={pending}
          className="ml-auto rounded-full border border-white/10 px-3 py-1.5 text-xs text-white/45 transition hover:border-white/25 hover:text-white/80 disabled:cursor-wait"
        >
          Reset network
        </button>
      </div>

      <div className="grid gap-5 lg:grid-cols-12">
        <form
          onSubmit={submit}
          className="card h-fit p-5 lg:col-span-4 lg:sticky lg:top-20 lg:max-h-[calc(100vh-6.5rem)] lg:overflow-y-auto"
        >
          <div className="flex items-center justify-between">
            <p className="text-[11px] font-medium uppercase tracking-[0.16em] text-white/40">
              Your plan
            </p>
            <span className="rounded-full border border-white/10 px-2 py-0.5 font-mono text-[10px] text-white/40">
              3 inputs
            </span>
          </div>
          <h2 className="mt-2 text-lg font-semibold tracking-tight text-white">
            Build the original plan
          </h2>
          <p className="mt-1 text-xs leading-relaxed text-white/45">
            PlanB checks availability first, then runs Dijkstra from your position and ranks every
            remaining match.
          </p>

          <div className="mt-5 space-y-4">
            <div className="space-y-1.5">
              <StepLabel step="01" htmlFor="origin">Where are you?</StepLabel>
              <div className="relative">
                <select
                  id="origin"
                  className="field"
                  value={originId}
                  disabled={pending}
                  onChange={(event) => {
                    const next = event.target.value;
                    setOriginId(next);
                    void recalc({ originId: next });
                  }}
                >
                  {origins.map((location) => (
                    <option key={location.id} value={location.id}>
                      {location.name} · {location.area}
                    </option>
                  ))}
                </select>
                <Chevron />
              </div>
            </div>

            <div className="space-y-1.5">
              <StepLabel step="02" htmlFor="need">What do you need?</StepLabel>
              <div className="relative">
                <select
                  id="need"
                  className="field"
                  value={need}
                  disabled={pending}
                  onChange={(event) => changeNeed(event.target.value)}
                >
                  {CATEGORIES.map((category) => (
                    <optgroup key={category.id} label={category.label}>
                      {category.services.map((service) => (
                        <option key={service} value={service}>
                          {service}
                        </option>
                      ))}
                    </optgroup>
                  ))}
                </select>
                <Chevron />
              </div>
              <p className="text-[11px] text-white/35">
                {preferredOptions.length} destinations list this service in the database.
              </p>
            </div>

            <div className="space-y-1.5">
              <StepLabel step="03" htmlFor="preferred">Preferred destination</StepLabel>
              <div className="relative">
                <select
                  id="preferred"
                  className="field"
                  value={preferredId}
                  disabled={pending}
                  onChange={(event) => {
                    const next = event.target.value;
                    setPreferredId(next);
                    void recalc({ preferredFacilityId: next || null });
                  }}
                >
                  <option value="">Let PlanB choose the best match</option>
                  {preferredOptions.map((facility) => (
                    <option key={facility.id} value={facility.id}>
                      {facility.name} · {STATUS_META[facility.status].label}
                    </option>
                  ))}
                </select>
                <Chevron />
              </div>
            </div>

            {preferredFacility && (
              <div
                className={`rounded-xl border p-3 text-xs ${
                  preferredFacility.status === "available"
                    ? "border-[#7CF2B0]/25 bg-[#7CF2B0]/[0.06]"
                    : "border-[#FFC46B]/25 bg-[#FFC46B]/[0.06]"
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="text-white/70">Plan A status</span>
                  <StatusPill status={preferredFacility.status} />
                </div>
                <p className="mt-1.5 leading-relaxed text-white/50">{preferredFacility.statusNote}</p>
                {preferredFacility.status !== "available" && (
                  <p className="mt-1.5 leading-relaxed text-[#FFD79A]/80">
                    This is exactly the case PlanB solves: the original destination cannot meet your
                    need right now.
                  </p>
                )}
              </div>
            )}

            <button type="submit" disabled={pending} className="btn-primary group w-full">
              <span>{pending ? "Recalculating…" : "Find Plan B"}</span>
              <span className="transition group-hover:translate-x-0.5">→</span>
            </button>

            {error && (
              <p className="rounded-lg border border-[#FF8296]/30 bg-[#FF8296]/10 px-3 py-2 text-xs text-[#FFB3C0]">
                {error}
              </p>
            )}
            <p role="status" className="min-h-[16px] text-[11px] leading-relaxed text-white/40">
              {notice ??
                `Dijkstra settled ${plan.algorithm.nodesSettled} of ${plan.algorithm.nodesInGraph} nodes in ${plan.algorithm.computationMs} ms.`}
            </p>
          </div>

          <div className="mt-4 flex items-center justify-between border-t border-white/8 pt-3 text-[11px] text-white/35">
            <span>
              {plan.blockedRoadCount} closed road{plan.blockedRoadCount === 1 ? "" : "s"} excluded
            </span>
            <Link href="/network" className="text-[#9DF8C9]/80 hover:text-[#C9FFE3]">
              Open network console ↗
            </Link>
          </div>
        </form>

        <div className="space-y-5 lg:col-span-8">
          <div
            className={`flex flex-col gap-2 rounded-2xl border p-4 sm:flex-row sm:items-center sm:justify-between ${
              !recommended
                ? "border-[#FF8296]/30 bg-[#FF8296]/[0.07]"
                : plan.preferredStillWorks
                  ? "border-[#7CF2B0]/25 bg-[#7CF2B0]/[0.06]"
                  : "border-[#FFC46B]/25 bg-[#FFC46B]/[0.06]"
            }`}
          >
            <div className="flex items-start gap-3">
              <span
                className={`mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-full text-sm ${
                  !recommended
                    ? "bg-[#FF8296]/15 text-[#FFB3C0]"
                    : plan.preferredStillWorks
                      ? "bg-[#7CF2B0]/15 text-[#9DF8C9]"
                      : "bg-[#FFC46B]/15 text-[#FFD79A]"
                }`}
              >
                {!recommended ? "!" : plan.preferredStillWorks ? "✓" : "↺"}
              </span>
              <div>
                <p className="text-sm font-semibold text-white">
                  {!recommended
                    ? "No viable alternative on the current network"
                    : plan.preferredStillWorks
                      ? "Plan A still works"
                      : "Plan A is off the table"}
                </p>
                <p className="mt-0.5 text-xs leading-relaxed text-white/55">
                  {!recommended
                    ? "Every matched destination is unavailable or cut off. Reopen a road or free up a facility status."
                    : plan.preferredStillWorks
                      ? `${plan.preferred?.facilityName} is available, ${formatKm(plan.preferred?.distanceKm ?? null)} km away. ${alternatives.length} backup option${alternatives.length === 1 ? "" : "s"} also ranked.`
                      : plan.preferred
                        ? `${plan.preferred.facilityName} cannot help right now. Dijkstra found ${plan.eligibleCount} available alternative${plan.eligibleCount === 1 ? "" : "s"} for ${plan.need}.`
                        : `No preferred destination was set. Dijkstra ranked ${plan.eligibleCount} available match${plan.eligibleCount === 1 ? "" : "es"} for ${plan.need} from your location.`}
                </p>
              </div>
            </div>
            <div className="flex shrink-0 items-center gap-2 pl-10 sm:pl-0">
              <span className="rounded-full border border-white/10 bg-black/20 px-2.5 py-1 font-mono text-[11px] text-white/60">
                {plan.matchedCount} matched
              </span>
              <span className="rounded-full border border-white/10 bg-black/20 px-2.5 py-1 font-mono text-[11px] text-white/60">
                {plan.eligibleCount} viable
              </span>
            </div>
          </div>

          <div className="card overflow-hidden p-4 pb-0">
            <div className="mb-3 flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="text-[11px] font-medium uppercase tracking-[0.16em] text-white/40">
                  Live network
                </p>
                <p className="mt-1 text-sm text-white">
                  {plan.origin.name}
                  <span className="mx-1.5 text-white/25">→</span>
                  {recommended ? recommended.facilityName : "no recommended destination"}
                </p>
              </div>
              <div className="flex items-center gap-2">
                {recommended && (
                  <span className="rounded-full border border-[#7CF2B0]/30 bg-[#7CF2B0]/10 px-3 py-1 font-mono text-xs text-[#C9FFE3]">
                    {formatKm(recommended.distanceKm)} km
                  </span>
                )}
                <button
                  type="button"
                  onClick={() => setShowAllPins((value) => !value)}
                  className="rounded-full border border-white/10 px-3 py-1 text-[11px] text-white/55 transition hover:border-white/25 hover:text-white"
                >
                  {showAllPins ? "Need only" : "All destinations"}
                </button>
              </div>
            </div>
            <NetworkMap
              network={network}
              activeCategory={plan.category}
              routeNodeIds={recommended?.nodeIds ?? []}
              routeRoadIds={recommended?.roadIds ?? []}
              originId={plan.origin.id}
              preferredFacilityId={plan.preferred?.facilityId ?? null}
              recommendedFacilityId={recommended?.facilityId ?? null}
              showAll={showAllPins}
              busy={pending}
              onToggleRoad={toggleRoad}
              onSelectFacility={selectFacility}
            />
            <div className="h-4" />
          </div>

          {recommended ? (
            <section className="relative overflow-hidden rounded-2xl border border-[#7CF2B0]/25 bg-gradient-to-br from-[#081812] via-[#081019] to-[#080D15] p-5">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div className="min-w-0">
                  <p className="flex items-center gap-2 text-[11px] font-medium uppercase tracking-[0.16em] text-[#7CF2B0]/80">
                    <span className="grid h-4 w-4 place-items-center rounded-full bg-[#7CF2B0] text-[9px] font-bold text-[#04150D]">
                      1
                    </span>
                    {plan.preferredStillWorks ? "Original plan confirmed" : "Recommended Plan B"}
                  </p>
                  <h3 className="mt-2 truncate text-xl font-semibold tracking-tight text-white">
                    {recommended.facilityName}
                  </h3>
                  <p className="mt-1 text-xs text-white/50">
                    {recommended.area} · {recommended.hours} · {recommended.statusNote}
                  </p>
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    <span className="rounded-full border border-[#7CF2B0]/25 bg-[#7CF2B0]/10 px-2.5 py-1 text-[11px] text-[#C9FFE3]">
                      {plan.need}
                    </span>
                    {recommended.reasonTags.map((tag) => (
                      <span
                        key={tag}
                        className="rounded-full border border-white/10 bg-white/[0.04] px-2.5 py-1 text-[11px] text-white/60"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-mono text-4xl font-semibold leading-none tracking-tight text-[#C9FFE3]">
                    {formatKm(recommended.distanceKm)}
                    <span className="ml-1 text-base font-normal text-white/40">km</span>
                  </p>
                  <p className="mt-1.5 text-[11px] text-white/40">
                    shortest path · ~{etaMinutes(recommended.distanceKm)} min drive
                  </p>
                  {formatDelta(recommended.deltaVsPreferredKm) && (
                    <p className="mt-1 text-[11px] text-[#9DF8C9]/80">
                      {formatDelta(recommended.deltaVsPreferredKm)}
                    </p>
                  )}
                </div>
              </div>
              <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-white/8 pt-4">
                <a href="#route" className="btn-primary px-4 py-2 text-xs">
                  View route steps
                </a>
                <button
                  type="button"
                  onClick={copyRoute}
                  className="btn-ghost px-4 py-2 text-xs"
                >
                  Copy directions
                </button>
                {recommended.facilityId !== preferredId && (
                  <button
                    type="button"
                    onClick={() => makePreferred(recommended)}
                    disabled={pending}
                    className="btn-ghost px-4 py-2 text-xs disabled:cursor-wait"
                  >
                    Make this Plan A
                  </button>
                )}
                <span className="ml-auto text-[11px] text-white/35">
                  Rank 1 of {plan.eligibleCount} viable · {recommended.nodeIds.length} nodes ·{" "}
                  {recommended.roadIds.length} roads
                </span>
              </div>
            </section>
          ) : (
            <section className="rounded-2xl border border-[#FF8296]/25 bg-[#FF8296]/[0.06] p-5">
              <h3 className="text-lg font-semibold text-white">PlanB could not place you</h3>
              <p className="mt-1 text-xs leading-relaxed text-white/55">
                {plan.unreachableCount} matched destination{plan.unreachableCount === 1 ? " is" : "s are"} unreachable
                and the rest report an unavailable service. Try reopening a closed road on the map, or
                mark a facility available in the network console.
              </p>
              <Link href="/network" className="btn-ghost mt-3 inline-flex px-4 py-2 text-xs">
                Open network console
              </Link>
            </section>
          )}
        </div>
      </div>

      <div className="grid gap-5 lg:grid-cols-12">
        <section className="card p-5 lg:col-span-8">
          <div className="flex flex-wrap items-end justify-between gap-2">
            <div>
              <p className="text-[11px] font-medium uppercase tracking-[0.16em] text-white/40">
                Ranked alternatives
              </p>
              <h2 className="mt-1 text-lg font-semibold tracking-tight text-white">
                {alternatives.length} other viable destination{alternatives.length === 1 ? "" : "s"}
              </h2>
            </div>
            <span className="rounded-full border border-white/10 px-2.5 py-1 text-[11px] text-white/45">
              sorted by finalized Dijkstra distance
            </span>
          </div>

          {alternatives.length === 0 ? (
            <p className="mt-4 rounded-xl border border-white/8 bg-white/[0.02] p-4 text-xs text-white/45">
              No backup destination offers {plan.need} under the current conditions.
            </p>
          ) : (
            <div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
              {alternatives.map((candidate) => (
                <article
                  key={candidate.facilityId}
                  className="flex flex-col rounded-xl border border-white/8 bg-white/[0.02] p-4 transition hover:border-white/16 hover:bg-white/[0.04]"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-[11px] text-white/35">
                      #{String(candidate.rank).padStart(2, "0")}
                    </span>
                    <StatusPill status={candidate.status} />
                  </div>
                  <h3 className="mt-2 text-sm font-semibold leading-snug text-white">
                    {candidate.facilityName}
                  </h3>
                  <p className="mt-0.5 text-[11px] text-white/40">
                    {candidate.area} · {candidate.hours}
                  </p>
                  <div className="mt-3 flex items-baseline justify-between">
                    <span className="font-mono text-xl font-semibold text-white/90">
                      {formatKm(candidate.distanceKm)}
                      <span className="ml-1 text-[11px] font-normal text-white/35">km</span>
                    </span>
                    {formatDelta(candidate.deltaVsPreferredKm) && (
                      <span
                        className={`rounded-full border px-2 py-0.5 text-[10px] ${
                          (candidate.deltaVsPreferredKm ?? 0) < 0
                            ? "border-[#7CF2B0]/25 bg-[#7CF2B0]/10 text-[#9DF8C9]"
                            : "border-white/10 bg-white/[0.04] text-white/45"
                        }`}
                      >
                        {formatDelta(candidate.deltaVsPreferredKm)}
                      </span>
                    )}
                  </div>
                  <p className="mt-2 line-clamp-2 text-[11px] leading-relaxed text-white/40">
                    {candidate.statusNote}
                  </p>
                  <button
                    type="button"
                    onClick={() => makePreferred(candidate)}
                    disabled={pending}
                    className="mt-3 w-full rounded-lg border border-white/10 px-3 py-1.5 text-[11px] text-white/60 transition hover:border-[#7CF2B0]/40 hover:text-[#C9FFE3] disabled:cursor-wait"
                  >
                    Set as preferred
                  </button>
                </article>
              ))}
            </div>
          )}

          {plan.ruledOut.length > 0 && (
            <div className="mt-5 border-t border-white/8 pt-4">
              <p className="text-[11px] font-medium uppercase tracking-[0.16em] text-white/40">
                Ruled out · {plan.ruledOut.length}
              </p>
              <div className="mt-2 divide-y divide-white/5">
                {plan.ruledOut.map((candidate) => (
                  <div
                    key={candidate.facilityId}
                    className="flex flex-wrap items-center gap-x-3 gap-y-1 py-2 text-xs"
                  >
                    <span className="min-w-0 flex-1 truncate text-white/70">
                      {candidate.facilityName}
                      {candidate.isPreferred && (
                        <span className="ml-2 rounded bg-white/8 px-1.5 py-0.5 font-mono text-[9px] uppercase text-white/40">
                          Plan A
                        </span>
                      )}
                    </span>
                    <span className="font-mono text-[11px] text-white/35">
                      {candidate.distanceKm === null
                        ? "unreachable"
                        : `${formatKm(candidate.distanceKm)} km`}
                    </span>
                    <StatusPill status={candidate.status} />
                    <span className="w-full text-[11px] text-[#FFB3C0]/70 sm:w-auto sm:flex-1 sm:text-right">
                      {candidate.ineligibleReason}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </section>

        <section className="card p-5 lg:col-span-4">
          <p className="text-[11px] font-medium uppercase tracking-[0.16em] text-white/40">
            Distance comparison
          </p>
          <h2 className="mt-1 text-lg font-semibold tracking-tight text-white">
            Every match, measured
          </h2>
          <div className="mt-4 space-y-3">
            {compareList.map((candidate) => {
              const width = candidate.distanceKm
                ? Math.max(4, (candidate.distanceKm / maxDistance) * 100)
                : 100;
              return (
                <div key={candidate.facilityId}>
                  <div className="flex items-baseline justify-between gap-2 text-[11px]">
                    <span
                      className={`truncate ${
                        candidate.isRecommended ? "text-[#C9FFE3]" : "text-white/55"
                      }`}
                    >
                      {candidate.facilityName}
                      {candidate.isPreferred && (
                        <span className="ml-1.5 font-mono text-[9px] uppercase text-[#FFC46B]/80">
                          plan A
                        </span>
                      )}
                    </span>
                    <span className="shrink-0 font-mono text-white/50">
                      {candidate.distanceKm === null ? "—" : `${formatKm(candidate.distanceKm)} km`}
                    </span>
                  </div>
                  <div className="mt-1 h-2 overflow-hidden rounded-full bg-white/[0.05]">
                    <div
                      className={`h-full rounded-full ${
                        candidate.isRecommended
                          ? "bg-[#7CF2B0]"
                          : candidate.eligible
                            ? "bg-white/25"
                            : "bg-[#FF8296]/40"
                      }`}
                      style={{ width: `${candidate.eligible ? width : 100}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
          <p className="mt-4 text-[11px] leading-relaxed text-white/35">
            Bar length is proportional to shortest-path distance, scaled to the furthest match
            ({formatKm(maxDistance)} km). Destinations that fail availability or reachability keep the
            full-width track in red.
          </p>
        </section>
      </div>

      <div className="grid gap-5 lg:grid-cols-12">
        <section id="route" className="card p-5 lg:col-span-5">
          <p className="text-[11px] font-medium uppercase tracking-[0.16em] text-white/40">
            Route, leg by leg
          </p>
          <h2 className="mt-1 text-lg font-semibold tracking-tight text-white">
            {recommended ? recommended.facilityName : "No route available"}
          </h2>
          {recommended && (
            <>
              <p className="mt-1 text-xs text-white/40">
                {plan.origin.name} → {recommended.locationName}
              </p>
              <ol className="mt-4 space-y-0">
                {recommended.path.map((step, index) => {
                  const previousDistance =
                    index === 0 ? 0 : recommended.path[index - 1].distanceFromOriginKm;
                  const legDistance = Math.max(0, step.distanceFromOriginKm - previousDistance);
                  const isLast = index === recommended.path.length - 1;
                  return (
                    <li key={step.nodeId} className="flex gap-3">
                      <div className="flex flex-col items-center">
                        <span
                          className={`mt-1 grid h-3 w-3 place-items-center rounded-full border ${
                            index === 0 || isLast
                              ? "border-[#7CF2B0] bg-[#7CF2B0]"
                              : "border-white/25 bg-[#0A0F17]"
                          }`}
                        />
                        {!isLast && <span className="my-0.5 w-px flex-1 bg-white/12" />}
                      </div>
                      <div className={`min-w-0 flex-1 ${isLast ? "pb-0" : "pb-3"}`}>
                        <p className="flex items-baseline justify-between gap-2 text-xs">
                          <span className={index === 0 || isLast ? "text-white" : "text-white/65"}>
                            {step.name}
                          </span>
                          <span className="shrink-0 font-mono text-[11px] text-white/35">
                            {index === 0 ? "0.0" : formatKm(step.distanceFromOriginKm)} km
                          </span>
                        </p>
                        {index > 0 && (
                          <p className="mt-0.5 text-[11px] text-white/35">
                            via {recommended.roadNames[index - 1]} · {formatKm(legDistance)} km
                          </p>
                        )}
                      </div>
                    </li>
                  );
                })}
              </ol>
              <div className="mt-4 grid grid-cols-3 gap-2 border-t border-white/8 pt-3 text-center">
                <div>
                  <p className="font-mono text-sm text-white">{formatKm(recommended.distanceKm)} km</p>
                  <p className="text-[10px] uppercase tracking-[0.1em] text-white/35">distance</p>
                </div>
                <div>
                  <p className="font-mono text-sm text-white">~{etaMinutes(recommended.distanceKm)} min</p>
                  <p className="text-[10px] uppercase tracking-[0.1em] text-white/35">drive time</p>
                </div>
                <div>
                  <p className="font-mono text-sm text-white">{recommended.roadIds.length}</p>
                  <p className="text-[10px] uppercase tracking-[0.1em] text-white/35">roads</p>
                </div>
              </div>
            </>
          )}
        </section>

        <section className="card p-5 lg:col-span-7">
          <p className="text-[11px] font-medium uppercase tracking-[0.16em] text-white/40">
            Decision trail
          </p>
          <h2 className="mt-1 text-lg font-semibold tracking-tight text-white">How PlanB chose this</h2>
          <ol className="mt-4 space-y-3">
            {[
              {
                title: "Requirement filter",
                detail: `${plan.matchedCount} destinations in the graph list ${plan.need}.`,
              },
              {
                title: "Availability + reachability",
                detail: `${plan.eligibleCount} pass the status check and have an open path. ${plan.ruledOut.length} ruled out.`,
              },
              {
                title: "Dijkstra from origin",
                detail: `Settled ${plan.algorithm.nodesSettled} nodes across ${plan.algorithm.edgesInGraph} open edges (${plan.blockedRoadCount} closed roads skipped), with ${plan.algorithm.edgesRelaxed} relaxations.`,
              },
              {
                title: "Sort + recommend",
                detail: recommended
                  ? `${recommended.facilityName} finalized at ${formatKm(recommended.distanceKm)} km — first in an ascending sort of ${plan.eligibleCount} viable destinations.`
                  : "No destination survived the filters.",
              },
            ].map((step, index) => (
              <li key={step.title} className="flex gap-3">
                <span className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full border border-white/12 bg-white/[0.04] font-mono text-[10px] text-white/50">
                  {String(index + 1).padStart(2, "0")}
                </span>
                <div>
                  <p className="text-xs font-semibold text-white/85">{step.title}</p>
                  <p className="mt-0.5 text-[11px] leading-relaxed text-white/45">{step.detail}</p>
                </div>
              </li>
            ))}
          </ol>
          <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
            {[
              { label: "complexity", value: plan.algorithm.complexity },
              { label: "nodes", value: String(plan.algorithm.nodesInGraph) },
              { label: "open edges", value: String(plan.algorithm.edgesInGraph) },
              { label: "compute", value: `${plan.algorithm.computationMs} ms` },
            ].map((metric) => (
              <div
                key={metric.label}
                className="rounded-lg border border-white/8 bg-black/20 px-3 py-2"
              >
                <p className="font-mono text-[11px] text-[#9DF8C9]/80">{metric.value}</p>
                <p className="text-[10px] uppercase tracking-[0.1em] text-white/30">{metric.label}</p>
              </div>
            ))}
          </div>
        </section>
      </div>

      <section className="card p-5">
        <button
          type="button"
          onClick={() => setTraceOpen((value) => !value)}
          className="flex w-full items-center justify-between gap-3 text-left"
          aria-expanded={traceOpen}
        >
          <div>
            <p className="text-[11px] font-medium uppercase tracking-[0.16em] text-white/40">
              Algorithm trace
            </p>
            <h2 className="mt-1 text-lg font-semibold tracking-tight text-white">
              Dijkstra settle order from {plan.origin.name}
            </h2>
          </div>
          <span className="shrink-0 rounded-full border border-white/10 px-3 py-1.5 text-[11px] text-white/55">
            {traceOpen ? "Hide" : "Show"} {plan.trace.length} steps
          </span>
        </button>

        {traceOpen && (
          <div className="mt-4 max-h-80 overflow-auto rounded-xl border border-white/8">
            <table className="w-full border-collapse text-left text-xs">
              <thead className="sticky top-0 bg-[#0B1119] text-[10px] uppercase tracking-[0.12em] text-white/35">
                <tr>
                  <th className="px-3 py-2 font-medium">Step</th>
                  <th className="px-3 py-2 font-medium">Node settled</th>
                  <th className="px-3 py-2 font-medium">Distance</th>
                  <th className="px-3 py-2 font-medium">Came from</th>
                </tr>
              </thead>
              <tbody>
                {plan.trace.map((row) => {
                  const hosted = facilityNamesByNode.get(row.nodeId);
                  return (
                    <tr key={`${row.step}-${row.nodeId}`} className="border-t border-white/5">
                      <td className="px-3 py-1.5 font-mono text-[11px] text-white/30">
                        {String(row.step).padStart(2, "0")}
                      </td>
                      <td className="px-3 py-1.5 text-white/70">
                        {row.nodeName}
                        {hosted && (
                          <span className="ml-2 text-[10px] text-[#FFC46B]/70">
                            {hosted.join(", ")}
                          </span>
                        )}
                      </td>
                      <td className="px-3 py-1.5 font-mono text-[11px] text-[#9DF8C9]/80">
                        {formatKm(row.distanceKm)} km
                      </td>
                      <td className="px-3 py-1.5 text-[11px] text-white/40">
                        {row.viaNodeName ? `${row.viaNodeName} · ${row.roadName}` : "source node"}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
