"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const LINKS = [
  { href: "/", label: "Planner" },
  { href: "/network", label: "Network" },
  { href: "/activity", label: "Activity" },
];

export default function SiteHeader() {
  const pathname = usePathname();

  return (
    <header className="sticky top-0 z-40 border-b border-white/8 bg-[#06090e]/85 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-6xl items-center gap-4 px-5">
        <Link href="/" className="flex items-center gap-2.5">
          <svg viewBox="0 0 28 28" className="h-8 w-8" aria-hidden="true">
            <rect
              width="28"
              height="28"
              rx="9"
              fill="#0B1A14"
              stroke="rgba(124,242,176,0.35)"
              strokeWidth="1"
            />
            <path
              d="M8 20.5V13.5a4 4 0 0 1 4-4h2.5a3 3 0 0 0 3-3"
              fill="none"
              stroke="#7CF2B0"
              strokeWidth="1.7"
              strokeLinecap="round"
            />
            <path
              d="M17.5 20.5h-3.2a2.3 2.3 0 0 1 0-4.6h2.4"
              fill="none"
              stroke="rgba(124,242,176,0.45)"
              strokeWidth="1.5"
              strokeLinecap="round"
            />
            <circle cx="8" cy="21" r="2.3" fill="#7CF2B0" />
            <circle cx="18.6" cy="6.5" r="2.1" fill="#7CF2B0" />
          </svg>
          <span className="flex items-baseline gap-0.5 text-[17px] font-semibold tracking-tight text-white">
            Plan<span className="text-[#7CF2B0]">B</span>
          </span>
          <span className="hidden rounded-full border border-white/10 px-2 py-0.5 font-mono text-[9px] uppercase tracking-[0.16em] text-white/35 sm:inline-block">
            alt-plan engine
          </span>
        </Link>

        <nav className="ml-auto flex items-center gap-1" aria-label="Primary">
          {LINKS.map((link) => {
            const active =
              link.href === "/" ? pathname === "/" : pathname.startsWith(link.href);
            return (
              <Link
                key={link.href}
                href={link.href}
                className={`rounded-lg px-3 py-1.5 text-[13px] font-medium transition ${
                  active
                    ? "bg-white/[0.07] text-white"
                    : "text-white/50 hover:bg-white/[0.04] hover:text-white/85"
                }`}
                aria-current={active ? "page" : undefined}
              >
                {link.label}
              </Link>
            );
          })}
        </nav>

        <span className="hidden items-center gap-1.5 rounded-full border border-[#7CF2B0]/25 bg-[#7CF2B0]/10 px-2.5 py-1 text-[10px] font-medium uppercase tracking-[0.12em] text-[#9DF8C9] md:inline-flex">
          <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-[#7CF2B0]" />
          live graph
        </span>
      </div>
    </header>
  );
}
