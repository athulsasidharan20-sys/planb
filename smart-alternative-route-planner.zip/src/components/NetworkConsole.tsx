"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import StatusPill from "./StatusPill";
import { postJson } from "@/lib/client-api";
import { CATEGORIES, categoryForId } from "@/lib/city-data";
import type { FacilityStatus, Network } from "@/lib/types";
import { STATUS_META, STATUS_ORDER } from "@/lib/ui";

export default function NetworkConsole({ initialNetwork }: { initialNetwork: Network }) {
  const [network, setNetwork] = useState<Network>(initialNetwork);
  const [category, setCategory] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<"all" | FacilityStatus>("all");
  const [query, setQuery] = useState("");
  const [pendingId, setPendingId] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const nodeById = useMemo(
    () => new Map(network.locations.map((location) => [location.id, location])),
    [network.locations],
  );

  const counts = useMemo(() => {
    const base: Record<FacilityStatus, number> = {
      available: 0,
      busy: 0,
      closed: 0,
      unavailable: 0,
    };
    for (const facility of network.facilities) base[facility.status] += 1;
    return base;
  }, [network.facilities]);

  const blockedRoads = network.roads.filter((road) => road.blocked).length;

  const filtered = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return network.facilities.filter((facility) => {
      if (category !== "all" && facility.category !== category) return false;
      if (statusFilter !== "all" && facility.status !== statusFilter) return false;
      if (
        needle.length > 0 &&
        !facility.name.toLowerCase().includes(needle) &&
        !facility.area.toLowerCase().includes(needle) &&
        !facility.services.some((service) => service.toLowerCase().includes(needle))
      ) {
        return false;
      }
      return true;
    });
  }, [network.facilities, category, statusFilter, query]);

  const roads = useMemo(
    () =>
      [...network.roads].sort(
        (a, b) => Number(b.blocked) - Number(a.blocked) || a.id.localeCompare(b.id),
      ),
    [network.roads],
  );

  async function updateStatus(id: string, status: FacilityStatus) {
    setPendingId(id);
    setError(null);
    try {
      const data = await postJson<{ network: Network }>(`/api/facilities/${id}`, { status });
      setNetwork(data.network);
      setNotice(
        `${data.network.facilities.find((facility) => facility.id === id)?.name ?? "Facility"} is now ${STATUS_META[status].label.toLowerCase()}. Plans re-rank instantly.`,
      );
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Could not update the facility.");
    } finally {
      setPendingId(null);
    }
  }

  async function toggleRoad(id: string, blocked: boolean) {
    setPendingId(id);
    setError(null);
    try {
      const data = await postJson<{ network: Network }>(`/api/roads/${id}`, {
        blocked: !blocked,
      });
      setNetwork(data.network);
      const road = data.network.roads.find((item) => item.id === id);
      setNotice(`${road?.name ?? "Road"} ${blocked ? "reopened" : "closed"}.`);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Could not update the road.");
    } finally {
      setPendingId(null);
    }
  }

  async function reset() {
    setPendingId("reset");
    setError(null);
    try {
      const data = await postJson<{ network: Network }>("/api/reset");
      setNetwork(data.network);
      setNotice("Demo network restored: every road open, seeded availability back in place.");
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Could not reset the network.");
    } finally {
      setPendingId(null);
    }
  }

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        {STATUS_ORDER.map((status) => (
          <div key={status} className="card p-4">
            <p className="font-mono text-2xl font-semibold text-white">{counts[status]}</p>
            <p className="mt-1 flex items-center gap-1.5 text-[11px] text-white/45">
              <span className={`h-1.5 w-1.5 rounded-full ${STATUS_META[status].dot}`} />
              {STATUS_META[status].label}
            </p>
          </div>
        ))}
        <div className="card p-4">
          <p className="font-mono text-2xl font-semibold text-white">{blockedRoads}</p>
          <p className="mt-1 flex items-center gap-1.5 text-[11px] text-white/45">
            <span className="h-1.5 w-1.5 rounded-full bg-[#FF8296]" />
            Roads closed
          </p>
        </div>
      </div>

      <div className="card flex flex-col gap-3 p-4 lg:flex-row lg:items-center">
        <div className="flex flex-1 flex-wrap gap-1.5">
          <button
            type="button"
            onClick={() => setCategory("all")}
            className={`rounded-full border px-3 py-1.5 text-xs transition ${
              category === "all"
                ? "border-[#7CF2B0]/40 bg-[#7CF2B0]/12 text-[#C9FFE3]"
                : "border-white/10 text-white/55 hover:border-white/25 hover:text-white"
            }`}
          >
            All categories
          </button>
          {CATEGORIES.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setCategory(item.id)}
              className={`rounded-full border px-3 py-1.5 text-xs transition ${
                category === item.id
                  ? "border-[#7CF2B0]/40 bg-[#7CF2B0]/12 text-[#C9FFE3]"
                  : "border-white/10 text-white/55 hover:border-white/25 hover:text-white"
              }`}
            >
              <span style={{ color: item.color }}>{item.icon}</span> {item.label}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-2">
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search facility or area"
            className="field !w-48 !py-1.5 !text-xs"
          />
          <select
            value={statusFilter}
            onChange={(event) => setStatusFilter(event.target.value as "all" | FacilityStatus)}
            className="field !w-36 !py-1.5 !text-xs"
            aria-label="Filter by availability"
          >
            <option value="all">Any status</option>
            {STATUS_ORDER.map((status) => (
              <option key={status} value={status}>
                {STATUS_META[status].label}
              </option>
            ))}
          </select>
          <button
            type="button"
            onClick={reset}
            disabled={pendingId !== null}
            className="btn-ghost !py-1.5 text-[11px] disabled:cursor-wait"
          >
            Reset
          </button>
        </div>
      </div>

      {(notice || error) && (
        <p
          role="status"
          className={`rounded-xl border px-4 py-2 text-xs ${
            error
              ? "border-[#FF8296]/30 bg-[#FF8296]/10 text-[#FFB3C0]"
              : "border-[#7CF2B0]/25 bg-[#7CF2B0]/[0.06] text-[#9DF8C9]"
          }`}
        >
          {error ?? notice}
        </p>
      )}

      <div className="grid gap-5 lg:grid-cols-12">
        <section className="card lg:col-span-7">
          <div className="flex items-center justify-between border-b border-white/8 px-5 py-3.5">
            <div>
              <p className="text-[11px] font-medium uppercase tracking-[0.16em] text-white/40">
                Facilities
              </p>
              <h2 className="mt-0.5 text-sm font-semibold text-white">
                {filtered.length} of {network.facilities.length} destinations
              </h2>
            </div>
            <Link href="/" className="text-[11px] text-[#9DF8C9]/80 hover:text-[#C9FFE3]">
              Re-plan ↗
            </Link>
          </div>
          <div className="divide-y divide-white/5 px-5">
            {filtered.map((facility) => {
              const categoryDef = categoryForId(facility.category);
              const isPending = pendingId === facility.id;
              return (
                <div key={facility.id} className="flex flex-wrap items-center gap-3 py-3">
                  <span
                    className="grid h-9 w-9 shrink-0 place-items-center rounded-lg border text-sm"
                    style={{
                      borderColor: `${categoryDef?.color ?? "#ffffff"}40`,
                      color: categoryDef?.color ?? "#ffffff",
                      backgroundColor: `${categoryDef?.color ?? "#ffffff"}12`,
                    }}
                  >
                    {categoryDef?.icon ?? "•"}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[13px] font-medium text-white">{facility.name}</p>
                    <p className="text-[11px] text-white/40">
                      {categoryDef?.label ?? facility.category} · {facility.area} · {facility.hours}
                    </p>
                    <p className="mt-0.5 truncate text-[11px] text-white/30">
                      {facility.services.join(" · ")}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <StatusPill status={facility.status} />
                    <select
                      value={facility.status}
                      disabled={isPending}
                      onChange={(event) =>
                        void updateStatus(facility.id, event.target.value as FacilityStatus)
                      }
                      aria-label={`Set availability for ${facility.name}`}
                      className="field !w-36 !py-1.5 !text-[11px] disabled:cursor-wait"
                    >
                      {STATUS_ORDER.map((status) => (
                        <option key={status} value={status}>
                          {STATUS_META[status].label}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              );
            })}
            {filtered.length === 0 && (
              <p className="py-8 text-center text-xs text-white/40">
                No destination matches those filters.
              </p>
            )}
          </div>
        </section>

        <section className="card h-fit lg:col-span-5">
          <div className="flex items-center justify-between border-b border-white/8 px-5 py-3.5">
            <div>
              <p className="text-[11px] font-medium uppercase tracking-[0.16em] text-white/40">
                Roads
              </p>
              <h2 className="mt-0.5 text-sm font-semibold text-white">
                {network.roads.length - blockedRoads} open · {blockedRoads} closed
              </h2>
            </div>
            <span className="font-mono text-[10px] uppercase tracking-[0.1em] text-white/30">
              adjacency list
            </span>
          </div>
          <div className="max-h-[520px] divide-y divide-white/5 overflow-auto px-5">
            {roads.map((road) => {
              const from = nodeById.get(road.fromId);
              const to = nodeById.get(road.toId);
              const isPending = pendingId === road.id;
              return (
                <div key={road.id} className="flex items-center gap-3 py-2.5">
                  <span
                    className={`h-2 w-2 shrink-0 rounded-full ${
                      road.blocked ? "bg-[#FF8296]" : "bg-white/25"
                    }`}
                  />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[12px] text-white/80">{road.name}</p>
                    <p className="truncate text-[10px] text-white/35">
                      {from?.name ?? road.fromId} ↔ {to?.name ?? road.toId} ·{" "}
                      {road.distanceKm.toFixed(2)} km
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => void toggleRoad(road.id, road.blocked)}
                    disabled={isPending}
                    className={`shrink-0 rounded-md border px-2 py-1 text-[10px] uppercase tracking-[0.08em] transition disabled:cursor-wait ${
                      road.blocked
                        ? "border-[#7CF2B0]/30 text-[#9DF8C9] hover:bg-[#7CF2B0]/10"
                        : "border-white/12 text-white/45 hover:border-[#FF8296]/40 hover:text-[#FFB3C0]"
                    }`}
                  >
                    {road.blocked ? "Reopen" : "Close"}
                  </button>
                </div>
              );
            })}
          </div>
        </section>
      </div>
    </div>
  );
}
