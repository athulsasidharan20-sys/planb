"use client";

import { useMemo, useState } from "react";
import { CATEGORIES, categoryForId } from "@/lib/city-data";
import type { Network } from "@/lib/types";

type Props = {
  network: Network;
  activeCategory: string;
  routeNodeIds: string[];
  routeRoadIds: string[];
  originId: string;
  preferredFacilityId: string | null;
  recommendedFacilityId: string | null;
  showAll: boolean;
  busy?: boolean;
  onToggleRoad: (roadId: string) => void;
  onSelectFacility: (facilityId: string) => void;
};

const SHORT_LABEL: Record<string, string> = {
  "f-sunrise-general": "Sunrise General",
  "f-green-valley": "Green Valley",
  "f-riverbend-clinic": "Riverbend Clinic",
  "f-lakeside-medical": "Lakeside Medical",
  "f-metro-care": "Metro Care",
  "f-volt-hub": "Volt Hub",
  "f-techpark-charge": "TechPark Supercharge",
  "f-market-charge": "Market Charge",
  "f-lakeview-ev": "Lakeview EV",
  "f-metro-atm-central": "MetroBank ATM",
  "f-city-atm-museum": "CityBank ATM",
  "f-south-atm": "South Market ATM",
  "f-union-atm-east": "Union ATM",
  "f-central-study": "Central Library",
  "f-riverside-study": "Riverside Study",
  "f-oldtown-reading": "Old Town Reading",
  "f-techpark-learning": "TechPark Learning",
  "f-citizen-central": "Civic Centre Central",
  "f-citizen-east": "Civic Centre East",
  "f-northgate-permits": "North Gate Permits",
};

export default function NetworkMap({
  network,
  activeCategory,
  routeNodeIds,
  routeRoadIds,
  originId,
  preferredFacilityId,
  recommendedFacilityId,
  showAll,
  busy = false,
  onToggleRoad,
  onSelectFacility,
}: Props) {
  const [hoveredRoadId, setHoveredRoadId] = useState<string | null>(null);

  const nodeById = useMemo(
    () => new Map(network.locations.map((location) => [location.id, location])),
    [network.locations],
  );
  const routeNodes = useMemo(() => new Set(routeNodeIds), [routeNodeIds]);
  const routeRoads = useMemo(() => new Set(routeRoadIds), [routeRoadIds]);

  const visibleFacilities = useMemo(
    () =>
      network.facilities.filter(
        (facility) => showAll || facility.category === activeCategory,
      ),
    [network.facilities, showAll, activeCategory],
  );

  const origin = nodeById.get(originId);
  const hoveredRoad = network.roads.find((road) => road.id === hoveredRoadId) ?? null;

  return (
    <div className="relative">
      <div className="relative overflow-hidden rounded-xl border border-white/8 bg-[#070B12]">
        <svg
          viewBox="0 0 1000 650"
          className="block h-auto w-full"
          role="img"
          aria-label={`Network map showing routes from ${origin?.name ?? "origin"} to recommended destinations`}
        >
          <defs>
            <pattern id="map-grid" width="50" height="50" patternUnits="userSpaceOnUse">
              <path d="M 50 0 L 0 0 0 50" fill="none" stroke="rgba(255,255,255,0.035)" strokeWidth="1" />
            </pattern>
            <radialGradient id="map-glow-a" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#7CF2B0" stopOpacity="0.16" />
              <stop offset="100%" stopColor="#7CF2B0" stopOpacity="0" />
            </radialGradient>
            <radialGradient id="map-glow-b" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#6E9BFF" stopOpacity="0.14" />
              <stop offset="100%" stopColor="#6E9BFF" stopOpacity="0" />
            </radialGradient>
          </defs>

          <rect width="1000" height="650" fill="#070B12" />
          <rect width="1000" height="650" fill="url(#map-grid)" />
          <circle cx="250" cy="330" r="260" fill="url(#map-glow-a)" />
          <circle cx="780" cy="420" r="240" fill="url(#map-glow-b)" />

          {network.roads.map((road) => {
            const from = nodeById.get(road.fromId);
            const to = nodeById.get(road.toId);
            if (!from || !to) return null;
            const onRoute = routeRoads.has(road.id);
            const hovered = hoveredRoadId === road.id;
            const midX = (from.x + to.x) / 2;
            const midY = (from.y + to.y) / 2;

            return (
              <g key={road.id}>
                <line
                  x1={from.x}
                  y1={from.y}
                  x2={to.x}
                  y2={to.y}
                  stroke={
                    road.blocked
                      ? "#FF8296"
                      : onRoute
                        ? "#7CF2B0"
                        : hovered
                          ? "rgba(255,255,255,0.42)"
                          : "rgba(255,255,255,0.16)"
                  }
                  strokeWidth={onRoute ? 4 : road.blocked ? 2 : 1.8}
                  strokeLinecap="round"
                  strokeDasharray={road.blocked ? "6 6" : undefined}
                  opacity={road.blocked ? 0.7 : 1}
                />
                {onRoute && (
                  <line
                    x1={from.x}
                    y1={from.y}
                    x2={to.x}
                    y2={to.y}
                    stroke="#03130C"
                    strokeWidth={1.5}
                    strokeLinecap="round"
                    strokeDasharray="7 9"
                    className="route-flow"
                    opacity={0.85}
                  />
                )}
                {onRoute && (
                  <text
                    x={midX}
                    y={midY - 6}
                    textAnchor="middle"
                    fontSize={9}
                    fill="#9DF8C9"
                    stroke="#05090F"
                    strokeWidth={3}
                    style={{ paintOrder: "stroke" }}
                  >
                    {road.name} · {road.distanceKm.toFixed(1)} km
                  </text>
                )}
                {road.blocked && (
                  <g pointerEvents="none">
                    <circle cx={midX} cy={midY} r={8} fill="#1C0C13" stroke="#FF8296" strokeWidth={1} />
                    <text x={midX} y={midY + 3.5} textAnchor="middle" fontSize={9} fill="#FF8296">
                      ×
                    </text>
                  </g>
                )}
                <line
                  x1={from.x}
                  y1={from.y}
                  x2={to.x}
                  y2={to.y}
                  stroke="transparent"
                  strokeWidth={15}
                  strokeLinecap="round"
                  className={busy ? "cursor-wait" : "cursor-pointer"}
                  onClick={() => {
                    if (!busy) onToggleRoad(road.id);
                  }}
                  onMouseEnter={() => setHoveredRoadId(road.id)}
                  onMouseLeave={() => setHoveredRoadId(null)}
                >
                  <title>{`${road.name} · ${road.distanceKm.toFixed(2)} km · ${road.blocked ? "Closed — click to reopen" : "Open — click to close"}`}</title>
                </line>
                {hovered && !onRoute && (
                  <text
                    x={midX}
                    y={midY - 8}
                    textAnchor="middle"
                    fontSize={9}
                    fill={road.blocked ? "#FFB3C0" : "#D8E4F4"}
                    stroke="#05090F"
                    strokeWidth={3}
                    style={{ paintOrder: "stroke" }}
                    pointerEvents="none"
                  >
                    {road.name} · {road.distanceKm.toFixed(1)} km · {road.blocked ? "reopen" : "close"}
                  </text>
                )}
              </g>
            );
          })}

          {network.locations
            .filter((location) => location.kind === "junction")
            .map((location) => {
              const onRoute = routeNodes.has(location.id);
              return (
                <g key={location.id}>
                  <circle
                    cx={location.x}
                    cy={location.y}
                    r={onRoute ? 5 : 3.5}
                    fill={onRoute ? "#7CF2B0" : "#0B1119"}
                    stroke={onRoute ? "#7CF2B0" : "rgba(255,255,255,0.35)"}
                    strokeWidth={1.5}
                  />
                  <text
                    x={location.x}
                    y={location.y + 17}
                    textAnchor="middle"
                    fontSize={8.5}
                    fill={onRoute ? "#9DF8C9" : "#63748B"}
                  >
                    {location.name}
                  </text>
                </g>
              );
            })}

          {visibleFacilities.map((facility) => {
            const category = categoryForId(facility.category) ?? CATEGORIES[0];
            const isRecommended = facility.id === recommendedFacilityId;
            const isPreferred = facility.id === preferredFacilityId;
            const dimmed = showAll && facility.category !== activeCategory;
            const label = SHORT_LABEL[facility.id] ?? facility.name;
            const anchorEnd = facility.x > 820;
            const labelAbove = facility.y > 540;

            return (
              <g
                key={facility.id}
                transform={`translate(${facility.x} ${facility.y})`}
                opacity={dimmed ? 0.38 : 1}
                className={busy ? "cursor-wait" : "cursor-pointer"}
                onClick={() => {
                  if (!busy) onSelectFacility(facility.id);
                }}
              >
                <title>{`${facility.name} · ${facility.status} · click to make this your plan`}</title>
                {isRecommended && (
                  <rect
                    x={-18}
                    y={-18}
                    width={36}
                    height={36}
                    rx={12}
                    fill="none"
                    stroke="#7CF2B0"
                    strokeWidth={1.5}
                    strokeDasharray="4 4"
                    opacity={0.9}
                  />
                )}
                {isPreferred && !isRecommended && (
                  <rect
                    x={-18}
                    y={-18}
                    width={36}
                    height={36}
                    rx={12}
                    fill="none"
                    stroke="#FFC46B"
                    strokeWidth={1.4}
                    strokeDasharray="3 4"
                  />
                )}
                <rect
                  x={-13}
                  y={-13}
                  width={26}
                  height={26}
                  rx={8}
                  fill={isRecommended ? "#7CF2B0" : "#0B1119"}
                  stroke={category.color}
                  strokeWidth={1.4}
                />
                <text
                  x={0}
                  y={4.5}
                  textAnchor="middle"
                  fontSize={12}
                  fill={isRecommended ? "#04150D" : category.color}
                >
                  {category.icon}
                </text>
                {(isRecommended || isPreferred) && (
                  <g transform={`translate(0 ${-31})`}>
                    <rect
                      x={-25}
                      y={-8}
                      width={50}
                      height={16}
                      rx={5}
                      fill={isRecommended ? "#7CF2B0" : "#FFC46B"}
                    />
                    <text
                      x={0}
                      y={3.5}
                      textAnchor="middle"
                      fontSize={8.5}
                      fontWeight={700}
                      fill="#04150D"
                      letterSpacing={0.6}
                    >
                      {isRecommended ? "PLAN B" : "PLAN A"}
                    </text>
                  </g>
                )}
                <text
                  x={anchorEnd ? -20 : 0}
                  y={labelAbove ? -22 : 32}
                  textAnchor={anchorEnd ? "end" : "middle"}
                  fontSize={9}
                  fill={isRecommended ? "#C9FFE3" : "#93A3B8"}
                  stroke="#05090F"
                  strokeWidth={2.5}
                  style={{ paintOrder: "stroke" }}
                >
                  {label}
                </text>
              </g>
            );
          })}

          {origin && (
            <g transform={`translate(${origin.x} ${origin.y})`} pointerEvents="none">
              <circle r={10} fill="none" stroke="#7CF2B0" strokeWidth={1.5} className="origin-pulse" />
              <circle r={7} fill="#7CF2B0" opacity={0.22} />
              <circle r={4.5} fill="#7CF2B0" stroke="#04150D" strokeWidth={1.5} />
              <g transform="translate(0 -19)">
                <rect x={-17} y={-9} width={34} height={16} rx={5} fill="#7CF2B0" />
                <text x={0} y={2.5} textAnchor="middle" fontSize={8.5} fontWeight={700} fill="#04150D" letterSpacing={0.6}>
                  YOU
                </text>
              </g>
            </g>
          )}
        </svg>

        {busy && (
          <div className="pointer-events-none absolute right-3 top-3 flex items-center gap-2 rounded-full border border-[#7CF2B0]/30 bg-[#06120C]/90 px-3 py-1.5 text-[11px] text-[#9DF8C9]">
            <span className="h-1.5 w-1.5 animate-ping rounded-full bg-[#7CF2B0]" />
            Re-running Dijkstra
          </div>
        )}
      </div>

      <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-2 text-[11px] text-white/45">
        <span className="inline-flex items-center gap-1.5">
          <span className="h-2 w-2 rounded-full bg-[#7CF2B0]" /> You
        </span>
        <span className="inline-flex items-center gap-1.5">
          <span className="h-0.5 w-5 rounded-full bg-[#7CF2B0]" /> Shortest route
        </span>
        <span className="inline-flex items-center gap-1.5">
          <span className="h-0.5 w-5 rounded-full bg-white/25" /> Open road
        </span>
        <span className="inline-flex items-center gap-1.5">
          <span className="h-0.5 w-5 rounded-full border-t border-dashed border-[#FF8296]" /> Closed road
        </span>
        <span className="ml-auto hidden items-center gap-1.5 text-white/35 sm:inline-flex">
          Tap a road to close it · tap a pin to re-plan
        </span>
      </div>
    </div>
  );
}
