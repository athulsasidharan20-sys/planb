import type { FacilityStatus } from "@/lib/types";
import { STATUS_META } from "@/lib/ui";

export default function StatusPill({
  status,
  label,
  className = "",
}: {
  status: FacilityStatus;
  label?: string;
  className?: string;
}) {
  const meta = STATUS_META[status];
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border ${meta.border} ${meta.surface} px-2 py-0.5 text-[10px] font-medium uppercase tracking-[0.08em] ${meta.text} ${className}`}
    >
      <span className={`h-1.5 w-1.5 rounded-full ${meta.dot}`} />
      {label ?? meta.label}
    </span>
  );
}
