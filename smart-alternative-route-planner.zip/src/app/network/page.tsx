import NetworkConsole from "@/components/NetworkConsole";
import { CATEGORIES } from "@/lib/city-data";
import { getNetwork } from "@/lib/queries";

export const dynamic = "force-dynamic";

export default async function NetworkPage() {
  const network = await getNetwork();
  const blocked = network.roads.filter((road) => road.blocked).length;
  const openFacilities = network.facilities.filter(
    (facility) => facility.status === "available",
  ).length;

  return (
    <main className="mx-auto max-w-6xl px-5 pb-10">
      <section className="py-10">
        <p className="text-[11px] font-medium uppercase tracking-[0.16em] text-[#7CF2B0]/70">
          Network console
        </p>
        <h1 className="mt-2 max-w-2xl text-[clamp(1.9rem,4vw,2.75rem)] font-semibold leading-tight tracking-[-0.03em] text-white">
          The graph is the product. Break it, and watch the plan adapt.
        </h1>
        <p className="mt-3 max-w-2xl text-sm leading-relaxed text-white/50">
          Every facility status and every closed road is persisted in PostgreSQL and re-read on each
          planner run. Move a destination to “service unavailable”, close a bridge, then return to the
          planner — Dijkstra re-ranks the alternatives from scratch.
        </p>
        <div className="mt-5 flex flex-wrap gap-2 text-[11px]">
          <span className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1 text-white/55">
            {network.locations.length} nodes
          </span>
          <span className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1 text-white/55">
            {network.roads.length - blocked} open / {blocked} closed roads
          </span>
          <span className="rounded-full border border-[#7CF2B0]/25 bg-[#7CF2B0]/[0.08] px-3 py-1 text-[#9DF8C9]">
            {openFacilities} facilities available now
          </span>
          <span className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1 text-white/55">
            {CATEGORIES.length} service categories
          </span>
        </div>
      </section>

      <NetworkConsole initialNetwork={network} />
    </main>
  );
}
