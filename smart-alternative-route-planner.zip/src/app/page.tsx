import Link from "next/link";
import Planner from "@/components/Planner";
import { DEFAULT_SCENARIO } from "@/lib/city-data";
import { computePlan } from "@/lib/planner";
import { getNetwork } from "@/lib/queries";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const network = await getNetwork();
  const plan = computePlan(network, {
    originId: DEFAULT_SCENARIO.originId,
    need: DEFAULT_SCENARIO.need,
    preferredFacilityId: DEFAULT_SCENARIO.preferredFacilityId,
  });

  const total = network.facilities.length;
  const available = network.facilities.filter((facility) => facility.status === "available").length;
  const degraded = network.facilities.filter((facility) => facility.status === "busy").length;
  const offline = total - available - degraded;
  const blocked = network.roads.filter((road) => road.blocked).length;
  const services = new Set(network.facilities.flatMap((facility) => facility.services)).size;

  const pulseRows = [
    { label: "Available now", value: available, total, tone: "#7CF2B0" },
    { label: "At capacity", value: degraded, total, tone: "#FFC46B" },
    { label: "Closed / service down", value: offline, total, tone: "#FF8296" },
    { label: "Roads closed", value: blocked, total: network.roads.length, tone: "#8FB8FF" },
  ];

  const steps = [
    {
      title: "Pick your need",
      detail: "Location, required service, and the destination you planned to use.",
    },
    {
      title: "Filter the graph",
      detail: "Destinations that do not offer the service or are unavailable drop out.",
    },
    {
      title: "Run Dijkstra",
      detail: "One shortest-path pass covers every remaining candidate from your origin.",
    },
    {
      title: "Rank the plan Bs",
      detail: "Finalized distances are sorted; the nearest viable match becomes the plan.",
    },
  ];

  const differentiators = [
    {
      title: "Destination-first, not route-first",
      detail:
        "Classic shortest-path apps assume the destination works. PlanB answers the harder question: which destination should you even be going to?",
    },
    {
      title: "The graph changes, the plan follows",
      detail:
        "Tap a road on the map to close it. The edge disappears from the adjacency list and Dijkstra re-runs over the reduced graph instantly.",
    },
    {
      title: "Every recommendation is explainable",
      detail:
        "Each run exposes matched destinations, ruled-out reasons, the settled node order, edge relaxations, and the sorted distance table.",
    },
  ];

  return (
    <main className="mx-auto max-w-6xl px-5 pb-6">
      <section className="grid gap-8 py-10 lg:grid-cols-[1.55fr_1fr] lg:items-center lg:py-14">
        <div>
          <p className="inline-flex items-center gap-2 rounded-full border border-[#7CF2B0]/25 bg-[#7CF2B0]/[0.08] px-3 py-1 text-[10px] font-medium uppercase tracking-[0.16em] text-[#9DF8C9]">
            <span className="h-1.5 w-1.5 rounded-full bg-[#7CF2B0]" />
            DSA prototype · graphs + Dijkstra
          </p>
          <h1 className="mt-5 text-[clamp(2.2rem,5.2vw,3.65rem)] font-semibold leading-[1.03] tracking-[-0.035em] text-white">
            Your plan just broke.
            <br />
            <span className="text-[#7CF2B0]">PlanB</span> already found the alternative.
          </h1>
          <p className="mt-5 max-w-xl text-sm leading-relaxed text-white/55 sm:text-[15px]">
            Tell PlanB what you need and where you were headed. It checks which destinations can
            actually serve that need right now, runs Dijkstra across the road graph, and ranks every
            viable option by true shortest-path distance — with the full route to prove it.
          </p>
          <div className="mt-6 flex flex-wrap items-center gap-2">
            <span className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1 text-[11px] text-white/60">
              {network.locations.length} graph nodes
            </span>
            <span className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1 text-[11px] text-white/60">
              {network.roads.length} weighted roads
            </span>
            <span className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1 text-[11px] text-white/60">
              {total} facilities · {services} services
            </span>
            <Link
              href="/network"
              className="rounded-full border border-[#7CF2B0]/30 bg-[#7CF2B0]/10 px-3 py-1 text-[11px] text-[#C9FFE3] transition hover:bg-[#7CF2B0]/20"
            >
              Tune the network →
            </Link>
          </div>
        </div>

        <div className="card p-5">
          <div className="flex items-center justify-between">
            <p className="text-[11px] font-medium uppercase tracking-[0.16em] text-white/40">
              Network pulse
            </p>
            <span className="inline-flex items-center gap-1.5 font-mono text-[9px] uppercase tracking-[0.12em] text-[#9DF8C9]">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-[#7CF2B0]" /> live
            </span>
          </div>
          <div className="mt-4 space-y-3">
            {pulseRows.map((row) => (
              <div key={row.label}>
                <div className="flex items-baseline justify-between text-[11px]">
                  <span className="text-white/55">{row.label}</span>
                  <span className="font-mono text-white/70">
                    {row.value}
                    <span className="text-white/25">/{row.total}</span>
                  </span>
                </div>
                <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-white/[0.06]">
                  <div
                    className="h-full rounded-full"
                    style={{
                      width: `${Math.max(4, (row.value / Math.max(1, row.total)) * 100)}%`,
                      backgroundColor: row.tone,
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 rounded-xl border border-white/8 bg-black/25 p-3">
            <p className="font-mono text-[10px] uppercase tracking-[0.1em] text-white/30">
              default scenario
            </p>
            <p className="mt-1 text-xs leading-relaxed text-white/60">
              {DEFAULT_SCENARIO.blurb}
            </p>
            <p className="mt-2 text-xs text-white/40">
              Plan A:{" "}
              <span className="text-white/70">{plan.preferred?.facilityName}</span> ·{" "}
              {plan.preferred?.distanceKm ?? "—"} km
              <br />
              Plan B:{" "}
              <span className="text-[#9DF8C9]">{plan.recommended?.facilityName}</span> ·{" "}
              {plan.recommended?.distanceKm ?? "—"} km
            </p>
          </div>
        </div>
      </section>

      <div className="grid gap-px overflow-hidden rounded-2xl border border-white/8 bg-white/8 sm:grid-cols-2 lg:grid-cols-4">
        {steps.map((step, index) => (
          <div key={step.title} className="bg-[#080d14] p-4">
            <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-[#7CF2B0]/70">
              step 0{index + 1}
            </p>
            <p className="mt-1.5 text-[13px] font-semibold text-white">{step.title}</p>
            <p className="mt-1 text-[11px] leading-relaxed text-white/40">{step.detail}</p>
          </div>
        ))}
      </div>

      <section className="mt-12">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="text-[11px] font-medium uppercase tracking-[0.16em] text-white/40">
              01 · Planner
            </p>
            <h2 className="mt-1 text-2xl font-semibold tracking-tight text-white">
              Find your Plan B
            </h2>
          </div>
          <p className="max-w-sm text-[11px] leading-relaxed text-white/35">
            Results are recomputed against the live database on every change. Click any road on the
            map to simulate a closure.
          </p>
        </div>
        <div className="mt-5">
          <Planner initialNetwork={network} initialPlan={plan} />
        </div>
      </section>

      <section className="mt-14">
        <p className="text-[11px] font-medium uppercase tracking-[0.16em] text-white/40">
          02 · Under the hood
        </p>
        <h2 className="mt-1 text-2xl font-semibold tracking-tight text-white">
          Built as a DSA project, shipped as a product
        </h2>
        <div className="mt-5 grid gap-4 md:grid-cols-3">
          {differentiators.map((item) => (
            <article key={item.title} className="card p-5">
              <h3 className="text-sm font-semibold text-white">{item.title}</h3>
              <p className="mt-2 text-xs leading-relaxed text-white/45">{item.detail}</p>
            </article>
          ))}
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          {[
            "Graph · nodes + weighted edges",
            "Adjacency list",
            "Binary min-heap",
            "Dijkstra shortest path",
            "Availability filter",
            "Ranking / sorting",
            "Path reconstruction",
          ].map((chip) => (
            <span
              key={chip}
              className="rounded-full border border-white/10 bg-white/[0.02] px-3 py-1 font-mono text-[10px] uppercase tracking-[0.08em] text-white/40"
            >
              {chip}
            </span>
          ))}
        </div>
      </section>
    </main>
  );
}
