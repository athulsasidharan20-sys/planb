import Link from "next/link";
import StatusPill from "@/components/StatusPill";
import { categoryForId } from "@/lib/city-data";
import { getActivityStats, getSearchHistory } from "@/lib/queries";
import type { FacilityStatus } from "@/lib/types";
import { formatDateTime, formatKm } from "@/lib/ui";

export const dynamic = "force-dynamic";

const STATUS_SET = new Set(["available", "busy", "closed", "unavailable"]);

export default async function ActivityPage() {
  const [history, stats] = await Promise.all([getSearchHistory(20), getActivityStats()]);

  const kpis = [
    { label: "Plan runs logged", value: String(stats.total), tone: "text-white" },
    {
      label: "Avg. alternatives per run",
      value: stats.avgAlternatives.toFixed(1),
      tone: "text-[#9DF8C9]",
    },
    {
      label: "Avg. recommended distance",
      value: `${stats.avgDistance.toFixed(1)} km`,
      tone: "text-white",
    },
    {
      label: "Runs with closed roads",
      value: String(stats.recalculated),
      tone: "text-[#FFD79A]",
    },
  ];

  return (
    <main className="mx-auto max-w-6xl px-5 pb-10">
      <section className="py-10">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-[11px] font-medium uppercase tracking-[0.16em] text-[#7CF2B0]/70">
              Activity
            </p>
            <h1 className="mt-2 text-[clamp(1.9rem,4vw,2.75rem)] font-semibold leading-tight tracking-[-0.03em] text-white">
              Every plan is persisted
            </h1>
            <p className="mt-3 max-w-2xl text-sm leading-relaxed text-white/50">
              PlanB writes each run to PostgreSQL: origin, required service, the original destination
              and its status, the recommended alternative, how many backups existed, and how many
              roads were closed at calculation time.
            </p>
          </div>
          <Link href="/" className="btn-primary px-4 py-2 text-xs">
            New plan →
          </Link>
        </div>

        <div className="mt-7 grid grid-cols-2 gap-3 lg:grid-cols-4">
          {kpis.map((kpi) => (
            <div key={kpi.label} className="card p-4">
              <p className={`font-mono text-2xl font-semibold ${kpi.tone}`}>{kpi.value}</p>
              <p className="mt-1 text-[11px] leading-relaxed text-white/40">{kpi.label}</p>
            </div>
          ))}
        </div>
      </section>

      <div className="grid gap-5 lg:grid-cols-12">
        <section className="card lg:col-span-8">
          <div className="flex items-center justify-between border-b border-white/8 px-5 py-3.5">
            <div>
              <p className="text-[11px] font-medium uppercase tracking-[0.16em] text-white/40">
                Plan log
              </p>
              <h2 className="mt-0.5 text-sm font-semibold text-white">
                Last {history.length} recommendation{history.length === 1 ? "" : "s"}
              </h2>
            </div>
            <span className="font-mono text-[10px] uppercase tracking-[0.1em] text-white/30">
              times shown in UTC
            </span>
          </div>

          {history.length === 0 ? (
            <div className="px-5 py-14 text-center">
              <p className="text-sm text-white/60">No plan runs yet.</p>
              <p className="mx-auto mt-1 max-w-sm text-xs leading-relaxed text-white/35">
                Generate a plan from the planner and it will appear here with its ranked
                alternatives.
              </p>
              <Link href="/" className="btn-ghost mt-4 inline-flex px-4 py-2 text-xs">
                Open the planner
              </Link>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[720px] border-collapse text-left text-xs">
                <thead className="text-[10px] uppercase tracking-[0.12em] text-white/35">
                  <tr className="border-b border-white/8">
                    <th className="px-5 py-2.5 font-medium">When</th>
                    <th className="px-3 py-2.5 font-medium">Origin</th>
                    <th className="px-3 py-2.5 font-medium">Need</th>
                    <th className="px-3 py-2.5 font-medium">Plan A</th>
                    <th className="px-3 py-2.5 font-medium">Plan B (km)</th>
                    <th className="px-3 py-2.5 font-medium">Alts</th>
                    <th className="px-5 py-2.5 font-medium">Closures</th>
                  </tr>
                </thead>
                <tbody>
                  {history.map((row) => {
                    const category = categoryForId(row.category);
                    const preferredStatus =
                      row.preferredStatus && STATUS_SET.has(row.preferredStatus)
                        ? (row.preferredStatus as FacilityStatus)
                        : null;
                    const usedPlanB =
                      row.recommendedFacilityName !== null &&
                      row.recommendedFacilityName !== row.preferredFacilityName;
                    return (
                      <tr
                        key={row.id}
                        className="border-b border-white/5 transition hover:bg-white/[0.02]"
                      >
                        <td className="whitespace-nowrap px-5 py-3 font-mono text-[11px] text-white/45">
                          {formatDateTime(row.createdAt)}
                        </td>
                        <td className="px-3 py-3 text-white/70">{row.originName}</td>
                        <td className="px-3 py-3">
                          <span className="text-white/70">{row.need}</span>
                          <span className="ml-1.5 text-[10px] text-white/25">
                            {category?.label ?? row.category}
                          </span>
                        </td>
                        <td className="px-3 py-3">
                          <div className="flex flex-col gap-1">
                            <span className="max-w-[170px] truncate text-white/55">
                              {row.preferredFacilityName ?? "No preference"}
                            </span>
                            {preferredStatus && <StatusPill status={preferredStatus} />}
                          </div>
                        </td>
                        <td className="px-3 py-3">
                          <div className="flex flex-col gap-1">
                            <span
                              className={`max-w-[190px] truncate ${
                                usedPlanB ? "text-[#9DF8C9]" : "text-white/60"
                              }`}
                            >
                              {row.recommendedFacilityName ?? "No match"}
                            </span>
                            <span className="font-mono text-[10px] text-white/35">
                              {formatKm(row.recommendedDistanceKm)} km
                            </span>
                          </div>
                        </td>
                        <td className="px-3 py-3 font-mono text-[11px] text-white/50">
                          {row.alternativesCount}
                        </td>
                        <td className="px-5 py-3">
                          <span
                            className={`font-mono text-[11px] ${
                              row.blockedRoads > 0 ? "text-[#FFD79A]" : "text-white/30"
                            }`}
                          >
                            {row.blockedRoads}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </section>

        <div className="space-y-5 lg:col-span-4">
          <section className="card p-5">
            <p className="text-[11px] font-medium uppercase tracking-[0.16em] text-white/40">
              Most requested needs
            </p>
            <div className="mt-3 space-y-2.5">
              {stats.topNeeds.length === 0 && (
                <p className="text-xs text-white/40">Nothing logged yet.</p>
              )}
              {stats.topNeeds.map((need) => {
                const percent = stats.total > 0 ? (need.count / stats.total) * 100 : 0;
                return (
                  <div key={need.need}>
                    <div className="flex items-baseline justify-between text-[11px]">
                      <span className="truncate text-white/60">{need.need}</span>
                      <span className="font-mono text-white/35">{need.count}</span>
                    </div>
                    <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-white/[0.06]">
                      <div
                        className="h-full rounded-full bg-[#7CF2B0]/70"
                        style={{ width: `${Math.max(6, percent)}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </section>

          <section className="card p-5">
            <p className="text-[11px] font-medium uppercase tracking-[0.16em] text-white/40">
              Most recommended
            </p>
            <div className="mt-3 divide-y divide-white/5">
              {stats.topDestinations.length === 0 && (
                <p className="text-xs text-white/40">No recommendations yet.</p>
              )}
              {stats.topDestinations.map((destination, index) => (
                <div
                  key={destination.name}
                  className="flex items-center gap-2.5 py-2 text-xs first:pt-0"
                >
                  <span className="font-mono text-[10px] text-white/25">
                    {String(index + 1).padStart(2, "0")}
                  </span>
                  <span className="min-w-0 flex-1 truncate text-white/65">{destination.name}</span>
                  <span className="font-mono text-[11px] text-[#9DF8C9]/70">
                    ×{destination.count}
                  </span>
                </div>
              ))}
            </div>
          </section>

          <section className="card p-5">
            <p className="text-[11px] font-medium uppercase tracking-[0.16em] text-white/40">
              Storage notes
            </p>
            <ul className="mt-2 space-y-1.5 text-[11px] leading-relaxed text-white/40">
              <li>· Facilities + services stored as PostgreSQL arrays.</li>
              <li>· Roads keep their weight and a live blocked flag.</li>
              <li>· Each planner run is appended to the log table.</li>
              <li>· Graph is rebuilt from the database per request.</li>
            </ul>
          </section>
        </div>
      </div>
    </main>
  );
}
