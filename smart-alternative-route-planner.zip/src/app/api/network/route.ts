import { getNetwork } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const network = await getNetwork();
    return Response.json({ network });
  } catch (error) {
    console.error("network fetch failed", error);
    return Response.json({ error: "Could not load the network." }, { status: 500 });
  }
}
