import { getNetwork, resetDemo } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function POST() {
  try {
    await resetDemo();
    const network = await getNetwork();
    return Response.json({ network });
  } catch (error) {
    console.error("reset failed", error);
    return Response.json({ error: "Could not reset the demo network." }, { status: 500 });
  }
}
