import { getNetwork, setRoadBlocked } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function POST(
  request: Request,
  context: { params: Promise<{ id: string }> },
) {
  const { id } = await context.params;
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return Response.json({ error: "Expected a JSON body." }, { status: 400 });
  }

  const blocked = (body as { blocked?: unknown } | null)?.blocked;
  if (typeof blocked !== "boolean") {
    return Response.json({ error: "`blocked` must be a boolean." }, { status: 400 });
  }

  try {
    const updated = await setRoadBlocked(id, blocked);
    if (!updated) return Response.json({ error: "Road not found." }, { status: 404 });
    const network = await getNetwork();
    return Response.json({ network });
  } catch (error) {
    console.error("road update failed", error);
    return Response.json({ error: "Could not update the road." }, { status: 500 });
  }
}
