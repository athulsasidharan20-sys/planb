import { getNetwork, setFacilityStatus } from "@/lib/queries";
import type { FacilityStatus } from "@/lib/types";

export const dynamic = "force-dynamic";

const STATUSES: FacilityStatus[] = ["available", "busy", "closed", "unavailable"];

export async function POST(
  request: Request,
  context: { params: Promise<{ id: string }> },
) {
  const { id } = await context.params;
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return Response.json({ error: "Expected a JSON body." }, { status: 400 });
  }

  const status = (body as { status?: unknown } | null)?.status;
  if (typeof status !== "string" || !STATUSES.includes(status as FacilityStatus)) {
    return Response.json({ error: "Unknown facility status." }, { status: 400 });
  }

  try {
    const updated = await setFacilityStatus(id, status as FacilityStatus);
    if (!updated) return Response.json({ error: "Facility not found." }, { status: 404 });
    const network = await getNetwork();
    return Response.json({ network });
  } catch (error) {
    console.error("facility update failed", error);
    return Response.json({ error: "Could not update the facility." }, { status: 500 });
  }
}
