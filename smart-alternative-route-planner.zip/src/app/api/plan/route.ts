import { CATEGORIES } from "@/lib/city-data";
import { computePlan } from "@/lib/planner";
import { getNetwork, recordSearch } from "@/lib/queries";

export const dynamic = "force-dynamic";

const SERVICES = new Set(CATEGORIES.flatMap((category) => category.services));

export async function POST(request: Request) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return Response.json({ error: "Expected a JSON body." }, { status: 400 });
  }

  const payload = body as {
    originId?: unknown;
    need?: unknown;
    preferredFacilityId?: unknown;
  } | null;

  const originId = typeof payload?.originId === "string" ? payload.originId : "";
  const need = typeof payload?.need === "string" ? payload.need : "";
  const preferredFacilityId =
    typeof payload?.preferredFacilityId === "string" && payload.preferredFacilityId.length > 0
      ? payload.preferredFacilityId
      : null;

  if (!originId) return Response.json({ error: "A starting location is required." }, { status: 400 });
  if (!SERVICES.has(need)) {
    return Response.json({ error: "Choose a service that PlanB tracks." }, { status: 400 });
  }

  try {
    const network = await getNetwork();
    if (!network.locations.some((location) => location.id === originId)) {
      return Response.json({ error: "Unknown starting location." }, { status: 400 });
    }

    const plan = computePlan(network, { originId, need, preferredFacilityId });
    try {
      await recordSearch(plan);
    } catch {
      // Logging a run should never break planning.
    }

    return Response.json({ plan, generatedAt: new Date().toISOString() });
  } catch (error) {
    console.error("plan failed", error);
    return Response.json({ error: "PlanB could not compute a plan." }, { status: 500 });
  }
}
