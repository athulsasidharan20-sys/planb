import type { Metadata } from "next";
import type { ReactNode } from "react";
import Link from "next/link";
import { Instrument_Sans, JetBrains_Mono } from "next/font/google";
import SiteHeader from "@/components/SiteHeader";
import "./globals.css";

const sans = Instrument_Sans({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-instrument",
});

const mono = JetBrains_Mono({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-jetbrains",
});

export const metadata: Metadata = {
  title: "PlanB · Smart Alternative Plan Generator",
  description:
    "PlanB matches the service you need against a live city graph, drops destinations that cannot help, and runs Dijkstra to rank the nearest viable alternative.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={`${sans.variable} ${mono.variable}`}>
      <body className="min-h-screen font-sans antialiased">
        <div className="flex min-h-screen flex-col">
          <SiteHeader />
          <div className="flex-1">{children}</div>
          <footer className="mt-14 border-t border-white/8 bg-black/20">
            <div className="mx-auto flex max-w-6xl flex-col gap-3 px-5 py-7 text-[11px] leading-relaxed text-white/35 sm:flex-row sm:items-center sm:justify-between">
              <p className="max-w-xl">
                PlanB is an educational DSA prototype running on a predefined city graph and
                simulated availability. It is not a medical or navigation service and must never
                replace emergency assistance — call your local emergency number instead.
              </p>
              <div className="flex flex-col gap-1 sm:items-end">
                <span className="font-mono text-[10px] uppercase tracking-[0.14em] text-white/30">
                  Dijkstra · adjacency lists · O((V+E) log V)
                </span>
                <Link href="/activity" className="text-white/45 transition hover:text-[#9DF8C9]">
                  View the plan log →
                </Link>
              </div>
            </div>
          </footer>
        </div>
      </body>
    </html>
  );
}
